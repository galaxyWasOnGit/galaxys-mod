
SMODS.Consumable {
    key = 'mrbeastticket',
    set = 'Tarot',
    pos = { x = 2, y = 0 },
    config = { 
        extra = {
            odds = 10,
            dollars0 = 1000   
        } 
    },
    loc_txt = {
        name = 'Mr Beast Ticket',
        text = {
            [1] = '{C:green}1 in 10{} chance it gives you {C:money}1000${}'
        }
    },
    cost = 3,
    unlocked = true,
    discovered = true,
    hidden = false,
    can_repeat_soul = false,
    atlas = 'CustomConsumables',
    use = function(self, card, area, copier)
        local used_card = copier or card
        if SMODS.pseudorandom_probability(card, 'group_0_9a8e8fb8', 1, card.ability.extra.odds, 'j_galaxysf_mrbeastticket', false) then
            G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.4,
                func = function()
                    
                    local current_dollars = G.GAME.dollars
                    local target_dollars = G.GAME.dollars + 1000
                    local dollar_value = target_dollars - current_dollars
                    card_eval_status_text(used_card, 'extra', nil, nil, nil, {message = "+"..tostring(1000).." $", colour = G.C.RED})
                    ease_dollars(dollar_value, true)
                    return true
                end
            }))
            delay(0.6)
            
        end
    end,
    can_use = function(self, card)
        return true
    end
}