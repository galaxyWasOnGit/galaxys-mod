
SMODS.Back {
    key = 'rofflelite_deck',
    pos = { x = 4, y = 0 },
    config = {
        extra = {
            remove_starting_cards_count0 = 46
        },
    },
    loc_txt = {
        name = 'Rofflelite Deck',
        text = {
            [1] = 'Start With{C:purple} Rofflelite{}'
        },
    },
    unlocked = true,
    discovered = true,
    no_collection = false,
    atlas = 'CustomDecks',
    apply = function(self, back)
        G.E_MANAGER:add_event(Event({
            func = function()
                play_sound('timpani')
                if #G.jokers.cards + G.GAME.joker_buffer < G.jokers.config.card_limit then
                    G.GAME.joker_buffer = G.GAME.joker_buffer + 1
                    local new_joker = SMODS.add_card({ set = 'Joker', key = 'j_galaxysf_rofflelite' })
                    if new_joker then
                    end
                    G.GAME.joker_buffer = 0
                end
                return true
            end
        }))
        for i = 1, 1 do
            G.E_MANAGER:add_event(Event({
                func = function()
                    if G.consumeables.config.card_limit > #G.consumeables.cards + G.GAME.consumeable_buffer then
                        G.GAME.consumeable_buffer = G.GAME.consumeable_buffer + 1
                    end
                    
                    
                    play_sound('timpani')
                    SMODS.add_card({ set = 'Tarot', edition = 'e_negative', key = 'c_galaxysf_rofflelitespecial'
                    })
                    return true
                end
            }))
        end
        local destroyed_cards = {}
        local temp_hand = {}
        G.E_MANAGER:add_event(Event({
            func = function()
            for _, playing_card in ipairs(G.deck.cards) do temp_hand[#temp_hand + 1] = playing_card end
                table.sort(temp_hand,
                    function(a, b)
                        return not a.playing_card or not b.playing_card or a.playing_card < b.playing_card
                    end
                )
                pseudoshuffle(temp_hand, 12345)    
                return true
            end,
        })) 
        
        G.E_MANAGER:add_event(Event({
            func = function()
                for i = 1, 46 do destroyed_cards[#destroyed_cards + 1] = temp_hand[i]:remove()
                end
                G.GAME.starting_deck_size = #G.playing_cards
                return true
            end
        }))
    end
}