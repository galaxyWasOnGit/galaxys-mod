
SMODS.Back {
    key = 'stone_deck',
    pos = { x = 5, y = 0 },
    config = {
        extra = {
            remove_starting_cards_count0 = 28
        },
    },
    loc_txt = {
        name = 'Stone Deck',
        text = {
            [1] = 'Start Off With 24 {C:attention}Stone{} Cards,',
            [2] = '',
            [3] = '{C:green} Stone Joker{}, {C:red}Gemstone Vein{}, And {C:attention}Golden Fever{}'
        },
    },
    unlocked = true,
    discovered = true,
    no_collection = false,
    atlas = 'CustomDecks',
    apply = function(self, back)
        G.E_MANAGER:add_event(Event({
            func = function()
                for k, v in pairs(G.playing_cards) do
                    v:set_ability(G.P_CENTERS['m_stone'])
                end
                G.GAME.starting_deck_size = #G.playing_cards
                return true
            end
        }))
        G.E_MANAGER:add_event(Event({
            func = function()
                play_sound('timpani')
                if #G.jokers.cards + G.GAME.joker_buffer < G.jokers.config.card_limit then
                    G.GAME.joker_buffer = G.GAME.joker_buffer + 1
                    local new_joker = SMODS.add_card({ set = 'Joker', key = 'j_stone' })
                    if new_joker then
                    end
                    G.GAME.joker_buffer = 0
                end
                return true
            end
        }))
        G.E_MANAGER:add_event(Event({
            func = function()
                play_sound('timpani')
                if #G.jokers.cards + G.GAME.joker_buffer < G.jokers.config.card_limit then
                    G.GAME.joker_buffer = G.GAME.joker_buffer + 1
                    local new_joker = SMODS.add_card({ set = 'Joker', key = 'j_galaxysf_gemstonevein' })
                    if new_joker then
                    end
                    G.GAME.joker_buffer = 0
                end
                return true
            end
        }))
        local destroyed_cards = {}
        local temp_hand = {}
        G.E_MANAGER:add_event(Event({
            func = function()
            for _, playing_card in ipairs(G.deck.cards) do temp_hand[#temp_hand + 1] = playing_card end
                table.sort(temp_hand,
                    function(a, b)
                        return not a.playing_card or not b.playing_card or a.playing_card < b.playing_card
                    end
                )
                pseudoshuffle(temp_hand, 12345)    
                return true
            end,
        })) 
        
        G.E_MANAGER:add_event(Event({
            func = function()
                for i = 1, 28 do destroyed_cards[#destroyed_cards + 1] = temp_hand[i]:remove()
                end
                G.GAME.starting_deck_size = #G.playing_cards
                return true
            end
        }))
        G.E_MANAGER:add_event(Event({
            func = function()
                play_sound('timpani')
                if #G.jokers.cards + G.GAME.joker_buffer < G.jokers.config.card_limit then
                    G.GAME.joker_buffer = G.GAME.joker_buffer + 1
                    local new_joker = SMODS.add_card({ set = 'Joker', key = 'j_galaxysf_midastouch' })
                    if new_joker then
                    end
                    G.GAME.joker_buffer = 0
                end
                return true
            end
        }))
    end
}