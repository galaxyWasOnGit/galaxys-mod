
SMODS.Back {
    key = 'ultra_hard_deck',
    pos = { x = 6, y = 0 },
    config = {
    },
    loc_txt = {
        name = 'Ultra Hard Deck',
        text = {
            [1] = 'Start Off With Jokertype_7 and Green Bean Watchu Mean',
            [2] = '',
            [3] = 'also start off with {C:money}25${} and all {C:hearts}Heart{} cards'
        },
    },
    unlocked = true,
    discovered = true,
    no_collection = false,
    atlas = 'CustomDecks',
    apply = function(self, back)
        G.E_MANAGER:add_event(Event({
            func = function()
                for k, v in pairs(G.playing_cards) do
                    assert(SMODS.change_base(v, 'Hearts'))
                end
                G.GAME.starting_deck_size = #G.playing_cards
                return true
            end
        }))
        G.E_MANAGER:add_event(Event({
            func = function()
                play_sound('timpani')
                if #G.jokers.cards + G.GAME.joker_buffer < G.jokers.config.card_limit then
                    G.GAME.joker_buffer = G.GAME.joker_buffer + 1
                    local new_joker = SMODS.add_card({ set = 'Joker', key = 'j_galaxysf_greenbeanwatchumean' })
                    if new_joker then
                    end
                    G.GAME.joker_buffer = 0
                end
                return true
            end
        }))
        G.GAME.starting_params.dollars = 25
    end
}