
SMODS.Joker{ --City Boy
    key = "cityboy",
    config = {
        extra = {
            xmult0 = 0.75,
            xchips0 = 2.5
        }
    },
    loc_txt = {
        ['name'] = 'City Boy',
        ['text'] = {
            [1] = '{X:red,C:white}X0.75{} Mult But {X:blue,C:white}X2.5{} Chips'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 5
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["galaxysf_galaxysf_jokers"] = true },
    
    set_ability = function(self, card, initial)
        card:set_edition("e_foil", true)
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                Xmult = 0.75,
                extra = {
                    x_chips = 2.5,
                    colour = G.C.DARK_EDITION
                }
            }
        end
    end
}