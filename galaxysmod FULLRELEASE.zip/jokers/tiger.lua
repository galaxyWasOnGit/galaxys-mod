
SMODS.Joker{ --Tiger
    key = "tiger",
    config = {
        extra = {
            xmult0 = 1.22
        }
    },
    loc_txt = {
        ['name'] = 'Tiger',
        ['text'] = {
            [1] = '{X:red,C:white}X1.22{} Mult on Each card',
            [2] = '',
            [3] = '(Galaxy\'s Cat)'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 3,
        y = 7
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = "galaxysf_pet",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["galaxysf_galaxysf_jokers"] = true, ["galaxysf_galaxysf_pets"] = true },
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            return {
                Xmult = 1.22
            }
        end
    end
}