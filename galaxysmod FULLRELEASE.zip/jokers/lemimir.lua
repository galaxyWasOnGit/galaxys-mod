
SMODS.Joker{ --Le Mimir
    key = "lemimir",
    config = {
        extra = {
            xmult0 = 50
        }
    },
    loc_txt = {
        ['name'] = 'Le Mimir',
        ['text'] = {
            [1] = '{X:red,C:white}X50{} Mult But Dissapears Afterwards'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 1,
        y = 5
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 9,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["galaxysf_galaxysf_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            local target_joker = card
            
            if target_joker then
                target_joker.getting_sliced = true
                G.E_MANAGER:add_event(Event({
                    func = function()
                        target_joker:start_dissolve({G.C.RED}, nil, 1.6)
                        return true
                    end
                }))
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Destroyed!", colour = G.C.RED})
            end
            return {
                Xmult = 50
            }
        end
    end
}