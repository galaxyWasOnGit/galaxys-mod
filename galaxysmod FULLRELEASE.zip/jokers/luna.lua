
SMODS.Joker{ --Luna
    key = "luna",
    config = {
        extra = {
            xchips0 = 3
        }
    },
    loc_txt = {
        ['name'] = 'Luna',
        ['text'] = {
            [1] = 'If you have peaches selected {X:blue,C:white} X3{} Chips',
            [2] = '',
            [3] = '(notice\'s cat)'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 1,
        y = 6
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = "galaxysf_pet",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["galaxysf_galaxysf_jokers"] = true, ["galaxysf_galaxysf_pets"] = true },
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if #G.jokers.highlighted > 0 and G.jokers.highlighted[1].config.center.key == "j_galaxysf_peaches" then
                return {
                    x_chips = 3
                }
            end
        end
    end
}