
SMODS.Joker{ --Washee Washee
    key = "washeewashee",
    config = {
        extra = {
            emult0 = 10,
            dollars0 = 10
        }
    },
    loc_txt = {
        ['name'] = 'Washee Washee',
        ['text'] = {
            [1] = 'Costs {C:red}-$10{} Per Hand For {X:tarot,C:white}^10{} Mult'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 5,
        y = 11
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = "galaxysf_godly",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["galaxysf_galaxysf_godlys"] = true },
    
    set_ability = function(self, card, initial)
        card:set_eternal(true)
        card:set_edition("e_holo", true)
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                e_mult = 10,
                extra = {
                    
                    func = function()
                        
                        local current_dollars = G.GAME.dollars
                        local target_dollars = G.GAME.dollars - 10
                        local dollar_value = target_dollars - current_dollars
                        ease_dollars(dollar_value)
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "-"..tostring(10), colour = G.C.MONEY})
                        return true
                    end,
                    colour = G.C.MONEY
                }
            }
        end
    end
}