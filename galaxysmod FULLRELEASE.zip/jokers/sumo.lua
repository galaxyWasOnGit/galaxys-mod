
SMODS.Joker{ --Sumo
    key = "sumo",
    config = {
        extra = {
            odds = 4,
            xmult0 = 5
        }
    },
    loc_txt = {
        ['name'] = 'Sumo',
        ['text'] = {
            [1] = '{C:green}#1# in 4{} Chance To Not Regret What He Did ({X:red,C:white}X5 {} Mult)'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 6,
        y = 8
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 8,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["galaxysf_galaxysf_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_galaxysf_sumo') 
        return {vars = {new_numerator, new_denominator}}
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if true then
                if SMODS.pseudorandom_probability(card, 'group_0_a44b6f38', 1, card.ability.extra.odds, 'j_galaxysf_sumo', false) then
                    G.E_MANAGER:add_event(Event({
                        func = function()
                            play_sound("galaxysf_nah")
                            
                            return true
                        end,
                    }))
                    SMODS.calculate_effect({Xmult = 5}, card)
                end
            end
        end
    end
}