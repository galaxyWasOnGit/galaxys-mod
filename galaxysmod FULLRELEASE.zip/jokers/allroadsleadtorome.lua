
SMODS.Joker{ --All Roads Lead To Rome
    key = "allroadsleadtorome",
    config = {
        extra = {
            xmult0 = 55
        }
    },
    loc_txt = {
        ['name'] = 'All Roads Lead To Rome',
        ['text'] = {
            [1] = '{X:red,C:white}X55{} Mult but for only Aces that are {C:attention}Gold{} and {C:spades}Spades{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 4,
        y = 4
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["galaxysf_galaxysf_jokers"] = true },
    
    set_ability = function(self, card, initial)
        card:set_eternal(true)
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if ((function()
                local count = 0
                for _, playing_card in pairs(context.scoring_hand or {}) do
                    if true then
                        count = count + 1
                    end
                end
                return count == #context.scoring_hand
            end)() and (function()
                local count = 0
                for _, playing_card in pairs(context.scoring_hand or {}) do
                    if true then
                        count = count + 1
                    end
                end
                return count == #context.scoring_hand
            end)()) then
                return {
                    Xmult = 55
                }
            end
        end
    end
}