
SMODS.Joker{ --Argartha Kirk
    key = "argarthakirk",
    config = {
        extra = {
            xmult0 = 2,
            dollars0 = 2
        }
    },
    loc_txt = {
        ['name'] = 'Argartha Kirk',
        ['text'] = {
            [1] = 'Each 2 Gives {C:attention}2${} and {X:red,C:white}X2{} Mult'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 3,
        y = 3
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 9,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["galaxysf_galaxysf_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if context.other_card:get_id() == 2 then
                G.E_MANAGER:add_event(Event({
                    func = function()
                        play_sound("galaxysf_landdownunder")
                        SMODS.calculate_effect({message = "Land Down Under"}, card)
                        return true
                    end,
                }))
                return {
                    Xmult = 2,
                    extra = {
                        
                        func = function()
                            
                            local current_dollars = G.GAME.dollars
                            local target_dollars = G.GAME.dollars + 2
                            local dollar_value = target_dollars - current_dollars
                            ease_dollars(dollar_value)
                            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(2), colour = G.C.MONEY})
                            return true
                        end,
                        colour = G.C.MONEY
                    }
                }
            end
        end
    end
}