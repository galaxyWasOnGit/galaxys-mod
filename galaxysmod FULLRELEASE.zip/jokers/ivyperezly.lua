
SMODS.Joker{ --Ivy Perezly
    key = "ivyperezly",
    config = {
        extra = {
            odds = 4,
            echips0 = 1.2,
            odds2 = 4,
            echips = 1.2
        }
    },
    loc_txt = {
        ['name'] = 'Ivy Perezly',
        ['text'] = {
            [1] = '{C:green}#1# in 4{} chance for {X:tarot,C:white}^1.2{} Chips On Each {C:hearts}Heart{} or {C:clubs}Club{} Card Played'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 3,
        y = 11
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 4,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["galaxysf_galaxysf_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_galaxysf_ivyperezly')
        local new_numerator2, new_denominator2 = SMODS.get_probability_vars(card, 1, card.ability.extra.odds2, 'j_galaxysf_ivyperezly')
        return {vars = {new_numerator, new_denominator, new_numerator2, new_denominator2}}
    end,
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if context.other_card:is_suit("Hearts") then
                if SMODS.pseudorandom_probability(card, 'group_0_26072b88', 1, card.ability.extra.odds, 'j_galaxysf_ivyperezly', false) then
                    SMODS.calculate_effect({e_chips = 1.2}, card)
                end
            elseif context.other_card:is_suit("Clubs") then
                if SMODS.pseudorandom_probability(card, 'group_0_bc8d3f5a', 1, card.ability.extra.odds, 'j_galaxysf_ivyperezly', false) then
                    SMODS.calculate_effect({e_chips = 1.2}, card)
                end
            end
        end
    end
}