
SMODS.Joker{ --Gengar
    key = "gengar",
    config = {
        extra = {
            odds = 8,
            odds2 = 4,
            sell_value0 = 9,
            sell_value = 14
        }
    },
    loc_txt = {
        ['name'] = 'Gengar',
        ['text'] = {
            [1] = '{C:green}#1# in 8{} chance to increase sell value by {C:money}$9{} each shop entered',
            [2] = '',
            [3] = '{C:green}#1# in 4{} chance to decrease sell value by {C:money}$14{} each shop entered',
            [4] = '',
            [5] = '{s:0.9}some call it a waste of money, we call it an investment{}',
            [6] = ''
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 8,
        y = 14
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = "galaxysf_trading_card",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["galaxysf_galaxysf_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_galaxysf_gengar')
        local new_numerator2, new_denominator2 = SMODS.get_probability_vars(card, 1, card.ability.extra.odds2, 'j_galaxysf_gengar')
        return {vars = {new_numerator, new_denominator, new_numerator2, new_denominator2}}
    end,
    
    calculate = function(self, card, context)
        if context.starting_shop  then
            if true then
                if SMODS.pseudorandom_probability(card, 'group_0_1b4a8833', 1, card.ability.extra.odds, 'j_galaxysf_gengar', false) then
                    SMODS.calculate_effect({func = function()local my_pos = nil
                        for i = 1, #G.jokers.cards do
                            if G.jokers.cards[i] == card then
                                my_pos = i
                                break
                            end
                        end
                        local target_card = G.jokers.cards[my_pos]
                        target_card.ability.extra_value = (card.ability.extra_value or 0) + 9
                        target_card:set_cost()
                        return true
                    end}, card)
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(9).." Sell Value", colour = G.C.MONEY})
                end
                if SMODS.pseudorandom_probability(card, 'group_1_44fb53b4', 1, card.ability.extra.odds2, 'j_galaxysf_gengar', false) then
                    SMODS.calculate_effect({func = function()local my_pos = nil
                        for i = 1, #G.jokers.cards do
                            if G.jokers.cards[i] == card then
                                my_pos = i
                                break
                            end
                        end
                        local target_card = G.jokers.cards[my_pos]
                        target_card.ability.extra_value = math.max(0, (card.ability.extra_value or 0) - 14)
                        target_card:set_cost()
                        return true
                    end}, card)
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "-"..tostring(14).." Sell Value", colour = G.C.MONEY})
                end
            end
        end
    end
}