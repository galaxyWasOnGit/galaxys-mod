
SMODS.Joker{ --George & Seri
    key = "georgeseri",
    config = {
        extra = {
            xmult0 = 2.5,
            xmult = 2.5
        }
    },
    loc_txt = {
        ['name'] = 'George & Seri',
        ['text'] = {
            [1] = 'Gives {X:red,C:white}X2{} Mult on Scored {C:spades}Spades{} and {C:clubs}Clubs{}',
            [2] = '',
            [3] = '(Cybron\'s Kitty Pair)'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 1,
        y = 8
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = "galaxysf_pet",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["galaxysf_galaxysf_jokers"] = true, ["galaxysf_galaxysf_pets"] = true },
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if context.other_card:is_suit("Spades") then
                return {
                    Xmult = 2.5
                }
            elseif context.other_card:is_suit("Clubs") then
                return {
                    Xmult = 2.5
                }
            end
        end
    end
}