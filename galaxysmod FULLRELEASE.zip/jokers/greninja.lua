
SMODS.Joker{ --Greninja
    key = "greninja",
    config = {
        extra = {
            odds = 1,
            odds2 = 2,
            sell_value0 = 3,
            sell_value = 4
        }
    },
    loc_txt = {
        ['name'] = 'Greninja',
        ['text'] = {
            [1] = '{C:green}#1# in 1{} chance to increase sell value by {C:money}$3{} each shop entered',
            [2] = '',
            [3] = '{C:green}#1# in 2{} chance to decrease sell value by {C:money}$4{} each shop entered',
            [4] = '',
            [5] = '{s:0.9}some call it a waste of money, we call it an investment{}',
            [6] = ''
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 9,
        y = 14
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = "galaxysf_trading_card",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["galaxysf_galaxysf_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_galaxysf_greninja')
        local new_numerator2, new_denominator2 = SMODS.get_probability_vars(card, 1, card.ability.extra.odds2, 'j_galaxysf_greninja')
        return {vars = {new_numerator, new_denominator, new_numerator2, new_denominator2}}
    end,
    
    calculate = function(self, card, context)
        if context.starting_shop  then
            if true then
                if SMODS.pseudorandom_probability(card, 'group_0_1b4a8833', 1, card.ability.extra.odds, 'j_galaxysf_greninja', false) then
                    SMODS.calculate_effect({func = function()local my_pos = nil
                        for i = 1, #G.jokers.cards do
                            if G.jokers.cards[i] == card then
                                my_pos = i
                                break
                            end
                        end
                        local target_card = G.jokers.cards[my_pos]
                        target_card.ability.extra_value = (card.ability.extra_value or 0) + 3
                        target_card:set_cost()
                        return true
                    end}, card)
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(3).." Sell Value", colour = G.C.MONEY})
                end
                if SMODS.pseudorandom_probability(card, 'group_1_44fb53b4', 1, card.ability.extra.odds2, 'j_galaxysf_greninja', false) then
                    SMODS.calculate_effect({func = function()local my_pos = nil
                        for i = 1, #G.jokers.cards do
                            if G.jokers.cards[i] == card then
                                my_pos = i
                                break
                            end
                        end
                        local target_card = G.jokers.cards[my_pos]
                        target_card.ability.extra_value = math.max(0, (card.ability.extra_value or 0) - 4)
                        target_card:set_cost()
                        return true
                    end}, card)
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "-"..tostring(4).." Sell Value", colour = G.C.MONEY})
                end
            end
        end
    end
}