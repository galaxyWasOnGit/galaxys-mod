
SMODS.Joker{ --Green Bean Watchu Mean
    key = "greenbeanwatchumean",
    config = {
        extra = {
            xmult0 = 0.1
        }
    },
    loc_txt = {
        ['name'] = 'Green Bean Watchu Mean',
        ['text'] = {
            [1] = '{X:red,C:white}X0.1{} Mult'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 2,
        y = 3
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 1,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["galaxysf_galaxysf_jokers"] = true },
    
    set_ability = function(self, card, initial)
        card:set_eternal(true)
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                Xmult = 0.1
            }
        end
    end
}