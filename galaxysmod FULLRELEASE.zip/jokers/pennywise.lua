
SMODS.Joker{ --Pennywise
    key = "pennywise",
    config = {
        extra = {
            xchips0 = 1.05
        }
    },
    loc_txt = {
        ['name'] = 'Pennywise',
        ['text'] = {
            [1] = '{X:blue,C:white}X1.05{} Chips On Each Card'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 2
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["galaxysf_galaxysf_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            G.E_MANAGER:add_event(Event({
                func = function()
                    play_sound("galaxysf_pattycake")
                    
                    return true
                end,
            }))
            return {
                x_chips = 1.05
            }
        end
    end
}