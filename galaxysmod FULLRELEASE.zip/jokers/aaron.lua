
SMODS.Joker{ --Aaron
    key = "aaron",
    config = {
        extra = {
            xmult0 = 5,
            xmult = 2.5
        }
    },
    loc_txt = {
        ['name'] = 'Aaron',
        ['text'] = {
            [1] = '{X:red,C:white}X2.5{} Mult, If Gamer Is Selected {X:red,C:white}X5{} Mult',
            [2] = '',
            [3] = '(High ahh cat)',
            [4] = '',
            [5] = '(Gamer\'s Cat)'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 4,
        y = 7
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = "galaxysf_pet",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["galaxysf_galaxysf_jokers"] = true, ["galaxysf_galaxysf_pets"] = true },
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if #G.jokers.highlighted > 0 and G.jokers.highlighted[1].config.center.key == "j_galaxysf_gamer" then
                return {
                    Xmult = 5
                }
            else
                return {
                    Xmult = 2.5
                }
            end
        end
    end
}