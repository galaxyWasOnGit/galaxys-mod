
SMODS.Joker{ --Joe Metri Desh
    key = "joemetridesh",
    config = {
        extra = {
            xmult0 = 3
        }
    },
    loc_txt = {
        ['name'] = 'Joe Metri Desh',
        ['text'] = {
            [1] = 'If Square Joker is Selected {X:red,C:white}X3{} Mult'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 8,
        y = 6
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["galaxysf_galaxysf_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if #G.jokers.highlighted > 0 and G.jokers.highlighted[1].config.center.key == "j_square" then
                return {
                    Xmult = 3
                }
            end
        end
    end
}