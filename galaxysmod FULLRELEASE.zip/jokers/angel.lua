
SMODS.Joker{ --Angel
    key = "angel",
    config = {
        extra = {
            AngelBonus = 1,
            xchips0 = 1.1,
            odds = 4
        }
    },
    loc_txt = {
        ['name'] = 'Angel',
        ['text'] = {
            [1] = '{X:blue,C:white}X1.1{} Chips On Each Card',
            [2] = '',
            [3] = '{C:green} #2# in 4{} chance to eat a card for x0.4 Extra Chips',
            [4] = '',
            [5] = 'Currently: {X:blue,C:white} X#1# {} Extra Chips On Each Card',
            [6] = '',
            [7] = '{s:0.9}(embodiment of a Mouse and a Guinea Pig Combined) {}',
            [8] = '',
            [9] = '(Bubbles\'s Chinchilla)'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 1,
        y = 13
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = "galaxysf_pet",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["galaxysf_galaxysf_jokers"] = true, ["galaxysf_galaxysf_pets"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_galaxysf_angel') 
        return {vars = {card.ability.extra.AngelBonus, new_numerator, new_denominator}}
    end,
    
    calculate = function(self, card, context)
        if context.destroy_card and context.destroy_card.should_destroy  then
            return { remove = true }
        end
        if context.individual and context.cardarea == G.play  then
            context.other_card.should_destroy = false
            if true then
                return {
                    x_chips = 1.1,
                    extra = {
                        x_chips = card.ability.extra.AngelBonus,
                        colour = G.C.DARK_EDITION
                    }
                    ,
                    func = function()
                        if SMODS.pseudorandom_probability(card, 'group_0_e930f0ae', 1, card.ability.extra.odds, 'j_galaxysf_angel', false) then
                            card.ability.extra.AngelBonus = (card.ability.extra.AngelBonus) + 0.4
                            
                        end
                        if SMODS.pseudorandom_probability(card, 'group_1_e930f0ae', 1, card.ability.extra.odds, 'j_galaxysf_angel', false) then
                            context.other_card.should_destroy = true
                            card.ability.extra.AngelBonus = (card.ability.extra.AngelBonus) + 0.4
                            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Destroyed!", colour = G.C.RED})
                        end
                        return true
                    end
                }
            end
        end
    end
}