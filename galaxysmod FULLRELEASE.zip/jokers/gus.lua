
SMODS.Joker{ --Gus
    key = "gus",
    config = {
        extra = {
            xchips0 = 1.25
        }
    },
    loc_txt = {
        ['name'] = 'Gus',
        ['text'] = {
            [1] = '{X:blue,C:white}1.25X{} Chips On Foil Cards',
            [2] = '',
            [3] = 'If Tiger Is selected {X:blue,C:white}X3{} Chips on every card',
            [4] = '',
            [5] = '(Bubbles\'s Cat)'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 4,
        y = 6
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = "galaxysf_pet",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["galaxysf_galaxysf_jokers"] = true, ["galaxysf_galaxysf_pets"] = true },
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if context.other_card.edition and context.other_card.edition.key == "foil" then
                return {
                    x_chips = 1.25
                }
            elseif #G.jokers.highlighted > 0 and G.jokers.highlighted[1].config.center.key == "j_galaxysf_tiger" then
            end
        end
    end
}