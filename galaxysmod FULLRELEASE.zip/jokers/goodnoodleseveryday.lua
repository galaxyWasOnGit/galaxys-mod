
SMODS.Joker{ --Good Noodles Everyday
    key = "goodnoodleseveryday",
    config = {
        extra = {
            xmult0 = 1.1
        }
    },
    loc_txt = {
        ['name'] = 'Good Noodles Everyday',
        ['text'] = {
            [1] = '{X:red,C:white}X1.1{} Mult on Each {C:diamonds}Diamond{} Card'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 7,
        y = 10
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["galaxysf_galaxysf_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if (function()
                local count = 0
                for _, playing_card in pairs(context.scoring_hand or {}) do
                    if true then
                        count = count + 1
                    end
                end
                return count == #context.scoring_hand
            end)() then
                return {
                    Xmult = 1.1
                }
            end
        end
    end
}