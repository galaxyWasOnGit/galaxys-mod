
SMODS.Joker{ --Young Sheldon
    key = "youngsheldon",
    config = {
        extra = {
            youngsheldonmult = 0
        }
    },
    loc_txt = {
        ['name'] = 'Young Sheldon',
        ['text'] = {
            [1] = 'Gains {X:red,C:white}X0.2{} Mult For Each {C:attention}Wild{} Card Scored',
            [2] = '',
            [3] = '(Currently:{X:red,C:white} X#1#{} Mult)'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 8,
        y = 11
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["galaxysf_galaxysf_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.youngsheldonmult}}
    end,
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if SMODS.get_enhancements(context.other_card)["m_wild"] == true then
                card.ability.extra.youngsheldonmult = (card.ability.extra.youngsheldonmult) + 0.2
            end
        end
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                Xmult = card.ability.extra.youngsheldonmult
            }
        end
    end
}