
SMODS.Joker{ --fentmaxxing
    key = "fentmaxxing",
    config = {
        extra = {
            emult0 = 1.1
        }
    },
    loc_txt = {
        ['name'] = 'fentmaxxing',
        ['text'] = {
            [1] = '{X:tarot,C:white}^1.1{} Mult if card played is {C:diamonds}Diamonds{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 3,
        y = 14
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["galaxysf_galaxysf_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if context.other_card:is_suit("Diamonds") then
                return {
                    e_mult = 1.1
                }
            end
        end
    end
}