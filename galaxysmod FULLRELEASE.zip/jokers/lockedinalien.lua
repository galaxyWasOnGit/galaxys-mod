
SMODS.Joker{ --Locked In Alien
    key = "lockedinalien",
    config = {
        extra = {
            odds = 4,
            emult0 = 1.3
        }
    },
    loc_txt = {
        ['name'] = 'Locked In Alien',
        ['text'] = {
            [1] = '{C:green}#1# in 4{} chance to lock in for {X:tarot,C:white}^1.3{} Mult'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 1,
        y = 12
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 35,
    rarity = "galaxysf_mythical",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["galaxysf_galaxysf_mythicals"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_galaxysf_lockedinalien') 
        return {vars = {new_numerator, new_denominator}}
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if true then
                if SMODS.pseudorandom_probability(card, 'group_0_7a44168f', 1, card.ability.extra.odds, 'j_galaxysf_lockedinalien', false) then
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Locked In", colour = G.C.WHITE})
                    SMODS.calculate_effect({e_mult = 1.3}, card)
                end
            end
        end
    end
}