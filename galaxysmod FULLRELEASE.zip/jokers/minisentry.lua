
SMODS.Joker{ --Mini Sentry
    key = "minisentry",
    config = {
        extra = {
            mult0 = 3,
            xmult0 = 1.12
        }
    },
    loc_txt = {
        ['name'] = 'Mini Sentry',
        ['text'] = {
            [1] = '{C:red}+3{} Mult and {X:red,C:white}X1.12{} Mult for each card played'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 3,
        y = 2
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 0,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["galaxysf_galaxysf_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            return {
                mult = 3,
                extra = {
                    Xmult = 1.12
                }
            }
        end
    end
}