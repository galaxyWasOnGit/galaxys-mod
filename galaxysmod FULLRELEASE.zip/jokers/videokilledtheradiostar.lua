
SMODS.Joker{ --Video Killed The Radio Star
    key = "videokilledtheradiostar",
    config = {
        extra = {
            xmult0 = 3.5
        }
    },
    loc_txt = {
        ['name'] = 'Video Killed The Radio Star',
        ['text'] = {
            [1] = '{X:red,C:white}X3.5{} Mult On Each Card',
            [2] = '',
            [3] = '(Rip MTV)'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 4,
        y = 9
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 20,
    rarity = 4,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["galaxysf_galaxysf_jokers"] = true },
    in_pool = function(self, args)
        return (
            not args 
            or args.source ~= 'sho' 
            or args.source == 'buf' or args.source == 'jud' or args.source == 'rif' or args.source == 'rta' or args.source == 'sou' or args.source == 'uta' or args.source == 'wra'
        )
        and true
    end,
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            return {
                Xmult = 3.5
            }
        end
    end
}