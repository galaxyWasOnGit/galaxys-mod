
SMODS.Joker{ --Gangle
    key = "gangle",
    config = {
        extra = {
            repetitions0 = 1,
            odds = 4
        }
    },
    loc_txt = {
        ['name'] = 'Gangle',
        ['text'] = {
            [1] = 'Retriggers Wrapped Cards',
            [2] = '',
            [3] = '{C:green}#1# in 4{} chance to make cards Wrapped'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 4,
        y = 13
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["galaxysf_galaxysf_jokers"] = true, ["galaxysf_galaxysf_tadc"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_galaxysf_gangle') 
        return {vars = {new_numerator, new_denominator}}
    end,
    
    calculate = function(self, card, context)
        if context.repetition and context.cardarea == G.play  then
            if context.other_card.seal == "Galaxysf_wrapped" then
                return {
                    repetitions = 1,
                    message = localize('k_again_ex')
                }
            elseif true then
                if SMODS.pseudorandom_probability(card, 'group_0_33f63252', 1, card.ability.extra.odds, 'j_galaxysf_gangle', false) then
                    local scored_card = context.other_card
                    G.E_MANAGER:add_event(Event({
                        func = function()
                            
                            scored_card:set_seal("galaxysf_wrapped", true)
                            card_eval_status_text(scored_card, 'extra', nil, nil, nil, {message = "Card Modified!", colour = G.C.ORANGE})
                            return true
                        end
                    }))
                    
                end
            end
        end
    end
}