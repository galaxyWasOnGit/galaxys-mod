
SMODS.Joker{ --Moe
    key = "moe",
    config = {
        extra = {
            odds = 4,
            xmult0 = 2.5
        }
    },
    loc_txt = {
        ['name'] = 'Moe',
        ['text'] = {
            [1] = '{C:green}#1# in 4{} Chance to ask for a lee key bum',
            [2] = '',
            [3] = '({X:red,C:white}X2.5{} Mult)'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 6,
        y = 5
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 7,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["galaxysf_galaxysf_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_galaxysf_moe') 
        return {vars = {new_numerator, new_denominator}}
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if true then
                if SMODS.pseudorandom_probability(card, 'group_0_316a1f73', 1, card.ability.extra.odds, 'j_galaxysf_moe', false) then
                    G.E_MANAGER:add_event(Event({
                        func = function()
                            play_sound("galaxysf_leekeybum")
                            
                            return true
                        end,
                    }))
                    SMODS.calculate_effect({Xmult = 2.5}, card)
                end
            end
        end
    end
}