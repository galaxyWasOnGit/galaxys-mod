
SMODS.Joker{ --Minimus
    key = "minimus",
    config = {
        extra = {
            MULT = 1,
            minimusmult = 15
        }
    },
    loc_txt = {
        ['name'] = 'Minimus',
        ['text'] = {
            [1] = 'Loses {X:red,C:white}X1.25{} Mult Each Round',
            [2] = '',
            [3] = '(Currently: {X:red,C:white} X#2# {} Mult)',
            [4] = '',
            [5] = '(ART BY {C:diamonds}u/Ornery_Wonder_2440{})'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 6,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 4,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["galaxysf_galaxysf_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.MULT, card.ability.extra.minimusmult}}
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                Xmult = card.ability.extra.minimusmult
            }
        end
        if context.end_of_round and context.game_over == false and context.main_eval  then
            return {
                func = function()
                    card.ability.extra.minimusmult = (card.ability.extra.minimusmult) + -1.25
                    return true
                end,
                extra = {
                    message = card.ability.extra.undefined,
                    colour = G.C.WHITE
                }
            }
        end
    end
}