
SMODS.Joker{ --Vro
    key = "vro",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'Vro',
        ['text'] = {
            [1] = 'Rest In Pickles'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 2,
        y = 4
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["galaxysf_galaxysf_jokers"] = true }
}