
SMODS.Joker{ --Pomni
    key = "pomni",
    config = {
        extra = {
            odds = 4,
            xmult0 = 1.5,
            odds2 = 4,
            xmult = 1.5
        }
    },
    loc_txt = {
        ['name'] = 'Pomni',
        ['text'] = {
            [1] = '{C:green}#1# in 4{} chance to give {X:red,C:white}X1.5{} Mult to a {C:hearts}Heart{} Or {C:clubs}Club{} Card'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 2,
        y = 13
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["galaxysf_galaxysf_jokers"] = true, ["galaxysf_galaxysf_tadc"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_galaxysf_pomni')
        local new_numerator2, new_denominator2 = SMODS.get_probability_vars(card, 1, card.ability.extra.odds2, 'j_galaxysf_pomni')
        return {vars = {new_numerator, new_denominator, new_numerator2, new_denominator2}}
    end,
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if context.other_card:is_suit("Hearts") then
                if SMODS.pseudorandom_probability(card, 'group_0_df065ec6', 1, card.ability.extra.odds, 'j_galaxysf_pomni', false) then
                    SMODS.calculate_effect({Xmult = 1.5}, card)
                end
            elseif context.other_card:is_suit("Clubs") then
                if SMODS.pseudorandom_probability(card, 'group_0_4039e310', 1, card.ability.extra.odds, 'j_galaxysf_pomni', false) then
                    SMODS.calculate_effect({Xmult = 1.5}, card)
                end
            end
        end
    end
}