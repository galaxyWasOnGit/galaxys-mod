
SMODS.Joker{ --Millennial Burger
    key = "millennialburger",
    config = {
        extra = {
            mult0 = 1981
        }
    },
    loc_txt = {
        ['name'] = 'Millennial Burger',
        ['text'] = {
            [1] = '{C:red}+1981{} Mult'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 4,
        y = 10
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = "galaxysf_godly",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["galaxysf_galaxysf_godlys"] = true },
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                mult = 1981
            }
        end
    end
}