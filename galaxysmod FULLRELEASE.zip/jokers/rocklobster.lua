
SMODS.Joker{ --Rock Lobster
    key = "rocklobster",
    config = {
        extra = {
            odds = 16
        }
    },
    loc_txt = {
        ['name'] = 'Rock Lobster',
        ['text'] = {
            [1] = '{C:green} #1# in 16{} Chance to turn a {C:attention}Stone{} card into a maxxed {C:attention}Stone{} card'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 7,
        y = 5
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["galaxysf_galaxysf_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_galaxysf_rocklobster') 
        return {vars = {new_numerator, new_denominator}}
    end,
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if SMODS.get_enhancements(context.other_card)["m_stone"] == true then
                if SMODS.pseudorandom_probability(card, 'group_0_288943f1', 1, card.ability.extra.odds, 'j_galaxysf_rocklobster', false) then
                    local scored_card = context.other_card
                    G.E_MANAGER:add_event(Event({
                        func = function()
                            
                            scored_card:set_ability(G.P_CENTERS.m_stone)
                            scored_card:set_seal("Red", true)
                            scored_card:set_edition("e_polychrome", true)
                            card_eval_status_text(scored_card, 'extra', nil, nil, nil, {message = "Card Modified!", colour = G.C.ORANGE})
                            return true
                        end
                    }))
                    G.E_MANAGER:add_event(Event({
                        func = function()
                            play_sound("galaxysf_Motion")
                            
                            return true
                        end,
                    }))
                    
                end
            end
        end
    end
}