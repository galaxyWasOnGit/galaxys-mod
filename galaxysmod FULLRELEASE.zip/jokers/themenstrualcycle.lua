
SMODS.Joker{ --The Menstrual Cycle
    key = "themenstrualcycle",
    config = {
        extra = {
            mult0 = 67,
            odds = 4
        }
    },
    loc_txt = {
        ['name'] = 'The Menstrual Cycle',
        ['text'] = {
            [1] = '{C:green}#1# in 4{} Chance To Play A Fuckass sound {C:red}+67{} Mult'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 6,
        y = 9
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 9,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["galaxysf_galaxysf_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_galaxysf_themenstrualcycle') 
        return {vars = {new_numerator, new_denominator}}
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if true then
                return {
                    mult = 67
                    ,
                    func = function()
                        if SMODS.pseudorandom_probability(card, 'group_0_82b01079', 1, card.ability.extra.odds, 'j_galaxysf_themenstrualcycle', false) then
                            G.E_MANAGER:add_event(Event({
                                func = function()
                                    play_sound("galaxysf_goofy")
                                    
                                    return true
                                end,
                            }))
                            
                        end
                        return true
                    end
                }
            end
        end
    end
}