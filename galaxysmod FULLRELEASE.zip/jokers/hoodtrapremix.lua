
SMODS.Joker{ --Hoodtrap Remix
    key = "hoodtrapremix",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'Hoodtrap Remix',
        ['text'] = {
            [1] = '{X:red,C:white}X100{} Mult if the card is a {C:attention}Lucky{} Wrapped {C:spades}Spade{} Ace'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 1,
        y = 14
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["galaxysf_galaxysf_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if (SMODS.get_enhancements(context.other_card)["m_lucky"] == true and context.other_card.seal == "Galaxysf_wrapped" and context.other_card:is_suit("Spades")) then
            end
        end
    end
}