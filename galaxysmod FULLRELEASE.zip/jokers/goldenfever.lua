
SMODS.Joker{ --Golden Fever
    key = "goldenfever",
    config = {
        extra = {
            repetitions0 = 1,
            repetitions = 1
        }
    },
    loc_txt = {
        ['name'] = 'Golden Fever',
        ['text'] = {
            [1] = 'Retrigger All Played {C:attention}Gold{} Or {C:attention}Stone{} Cards',
            [2] = '',
            [3] = '(Idea And Art By {C:attention}U/Ecstatic_End8547{})'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 5,
        y = 4
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 7,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["galaxysf_galaxysf_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.repetition and context.cardarea == G.play  then
            if SMODS.get_enhancements(context.other_card)["m_stone"] == true then
                return {
                    repetitions = 1,
                    message = localize('k_again_ex')
                }
            elseif SMODS.get_enhancements(context.other_card)["m_gold"] == true then
                return {
                    repetitions = 1,
                    message = localize('k_again_ex')
                }
            end
        end
    end
}