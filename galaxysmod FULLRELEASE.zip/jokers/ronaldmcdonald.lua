
SMODS.Joker{ --Ronald Mcdonald
    key = "ronaldmcdonald",
    config = {
        extra = {
            xmult0 = 1.5,
            xmult = 1.5
        }
    },
    loc_txt = {
        ['name'] = 'Ronald Mcdonald',
        ['text'] = {
            [1] = '{X:red,C:white}X1.5{} Mult For Every {C:hearts}Heart{} And {C:diamonds}Diamond{} Card'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 4,
        y = 3
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 20,
    rarity = 4,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["galaxysf_galaxysf_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if context.other_card:is_suit("Hearts") then
                return {
                    Xmult = 1.5
                }
            elseif context.other_card:is_suit("Diamonds") then
                return {
                    Xmult = 1.5
                }
            end
        end
    end
}