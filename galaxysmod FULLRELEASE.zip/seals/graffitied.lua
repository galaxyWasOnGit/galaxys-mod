
SMODS.Seal {
    key = 'graffitied',
    pos = { x = 2, y = 0 },
    config = {
        extra = {
            xmult0 = 0.75
        }
    },
    badge_colour = HEX('DC143C'),
    loc_txt = {
        name = 'Graffitied',
        label = 'Graffitied',
        text = {
            [1] = '{X:red,C:white}X0.75{} Mult',
            [2] = '',
            [3] = '{s:0.75}You can barely make out a purple rabbits face on it, smiling warmly{}'
        }
    },
    atlas = 'CustomSeals',
    unlocked = true,
    discovered = true,
    no_collection = false,
    calculate = function(self, card, context)
        if context.main_scoring and context.cardarea == G.play then
            return {
                Xmult = 0.75
            }
        end
    end
}