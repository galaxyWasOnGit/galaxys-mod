
SMODS.Seal {
    key = 'goldstake',
    pos = { x = 4, y = 0 },
    config = {
        extra = {
            xmult0 = 2.5
        }
    },
    badge_colour = HEX('000000'),
    loc_txt = {
        name = 'Gold Stake',
        label = 'Gold Stake',
        text = {
            [1] = '{X:red,C:white}X2.5{} Mult'
        }
    },
    atlas = 'CustomSeals',
    unlocked = true,
    discovered = true,
    no_collection = false,
    calculate = function(self, card, context)
        if context.main_scoring and context.cardarea == G.play then
            return {
                Xmult = 2.5
            }
        end
    end
}