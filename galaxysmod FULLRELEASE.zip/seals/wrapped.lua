
SMODS.Seal {
    key = 'wrapped',
    pos = { x = 3, y = 0 },
    config = {
        extra = {
            xchips0 = 1.1
        }
    },
    badge_colour = HEX('FF6B6B'),
    loc_txt = {
        name = 'Wrapped',
        label = 'Wrapped',
        text = {
            [1] = '{X:blue,C:white}X1.1{} Chips'
        }
    },
    atlas = 'CustomSeals',
    unlocked = true,
    discovered = true,
    no_collection = false,
    calculate = function(self, card, context)
        if context.main_scoring and context.cardarea == G.play then
            return {
                x_chips = 1.1
            }
        end
    end
}