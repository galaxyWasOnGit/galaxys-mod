SMODS.Atlas({
    key = "modicon", 
    path = "ModIcon.png", 
    px = 34,
    py = 34,
    atlas_table = "ASSET_ATLAS"
})

SMODS.Atlas({
    key = "balatro", 
    path = "balatro.png", 
    px = 333,
    py = 216,
    prefix_config = { key = false },
    atlas_table = "ASSET_ATLAS"
})


SMODS.Atlas({
    key = "CustomJokers", 
    path = "CustomJokers.png", 
    px = 71,
    py = 95, 
    atlas_table = "ASSET_ATLAS"
})

SMODS.Atlas({
    key = "CustomConsumables", 
    path = "CustomConsumables.png", 
    px = 71,
    py = 95, 
    atlas_table = "ASSET_ATLAS"
})

SMODS.Atlas({
    key = "CustomBoosters", 
    path = "CustomBoosters.png", 
    px = 71,
    py = 95, 
    atlas_table = "ASSET_ATLAS"
})

SMODS.Atlas({
    key = "CustomEnhancements", 
    path = "CustomEnhancements.png", 
    px = 71,
    py = 95, 
    atlas_table = "ASSET_ATLAS"
})

SMODS.Atlas({
    key = "CustomSeals", 
    path = "CustomSeals.png", 
    px = 71,
    py = 95, 
    atlas_table = "ASSET_ATLAS"
}):register()

SMODS.Atlas({
    key = "CustomDecks", 
    path = "CustomDecks.png", 
    px = 71,
    py = 95, 
    atlas_table = "ASSET_ATLAS"
})

local NFS = require("nativefs")
to_big = to_big or function(a) return a end
lenient_bignum = lenient_bignum or function(a) return a end

local jokerIndexList = {28,21,41,70,7,29,90,12,111,131,73,74,83,95,16,96,85,135,40,64,101,139,33,86,114,42,61,99,50,93,143,36,56,8,115,44,3,100,127,47,80,69,141,144,5,51,1,34,82,17,25,75,121,126,117,35,88,113,108,87,22,79,149,32,58,120,18,77,68,67,91,118,116,134,2,124,15,13,119,137,26,46,78,89,94,98,129,145,49,130,106,81,123,125,140,9,133,14,19,24,148,53,146,110,84,55,71,52,107,10,54,27,4,65,112,142,30,122,147,138,60,76,63,31,39,38,11,97,62,136,6,104,66,43,109,72,150,48,23,20,59,132,37,105,92,102,128,45,57,103}

local function load_jokers_folder()
    local mod_path = SMODS.current_mod.path
    local jokers_path = mod_path .. "/jokers"
    local files = NFS.getDirectoryItemsInfo(jokers_path)
    for i = 1, #jokerIndexList do
        local file_name = files[jokerIndexList[i]].name
        if file_name:sub(-4) == ".lua" then
            assert(SMODS.load_file("jokers/" .. file_name))()
        end
    end
end


local consumableIndexList = {4,3,1,2}

local function load_consumables_folder()
    local mod_path = SMODS.current_mod.path
    local consumables_path = mod_path .. "/consumables"
    local files = NFS.getDirectoryItemsInfo(consumables_path)
    local set_file_number = #files + 1
    for i = 1, #files do
        if files[i].name == "sets.lua" then
            assert(SMODS.load_file("consumables/sets.lua"))()
            set_file_number = i
        end
    end    
    for i = 1, #consumableIndexList do
        local j = consumableIndexList[i]
        if j >= set_file_number then 
            j = j + 1
        end
        local file_name = files[j].name
        if file_name:sub(-4) == ".lua" then
            assert(SMODS.load_file("consumables/" .. file_name))()
        end
    end
end


local enhancementIndexList = {1}

local function load_enhancements_folder()
    local mod_path = SMODS.current_mod.path
    local enhancements_path = mod_path .. "/enhancements"
    local files = NFS.getDirectoryItemsInfo(enhancements_path)
    for i = 1, #enhancementIndexList do
        local file_name = files[enhancementIndexList[i]].name
        if file_name:sub(-4) == ".lua" then
            assert(SMODS.load_file("enhancements/" .. file_name))()
        end
    end
end


local sealIndexList = {2,1,4,5,3}

local function load_seals_folder()
    local mod_path = SMODS.current_mod.path
    local seals_path = mod_path .. "/seals"
    local files = NFS.getDirectoryItemsInfo(seals_path)
    for i = 1, #sealIndexList do
        local file_name = files[sealIndexList[i]].name
        if file_name:sub(-4) == ".lua" then
            assert(SMODS.load_file("seals/" .. file_name))()
        end
    end
end


local editionIndexList = {1,3,4,2}

local function load_editions_folder()
    local mod_path = SMODS.current_mod.path
    local editions_path = mod_path .. "/editions"
    local files = NFS.getDirectoryItemsInfo(editions_path)
    for i = 1, #editionIndexList do
        local file_name = files[editionIndexList[i]].name
        if file_name:sub(-4) == ".lua" then
            assert(SMODS.load_file("editions/" .. file_name))()
        end
    end
end


local deckIndexList = {1,12,5,16,10,11,14,15,4,3,8,6,2,13,9,7}

local function load_decks_folder()
    local mod_path = SMODS.current_mod.path
    local decks_path = mod_path .. "/decks"
    local files = NFS.getDirectoryItemsInfo(decks_path)
    for i = 1, #deckIndexList do
        local file_name = files[deckIndexList[i]].name
        if file_name:sub(-4) == ".lua" then
            assert(SMODS.load_file("decks/" .. file_name))()
        end
    end
end

local function load_rarities_file()
    local mod_path = SMODS.current_mod.path
    assert(SMODS.load_file("rarities.lua"))()
end

load_rarities_file()

local function load_boosters_file()
    local mod_path = SMODS.current_mod.path
    assert(SMODS.load_file("boosters.lua"))()
end

load_boosters_file()
assert(SMODS.load_file("sounds.lua"))()
load_jokers_folder()
load_consumables_folder()
load_enhancements_folder()
load_seals_folder()
load_editions_folder()
load_decks_folder()
SMODS.ObjectType({
    key = "galaxysf_food",
    cards = {
        ["j_gros_michel"] = true,
        ["j_egg"] = true,
        ["j_ice_cream"] = true,
        ["j_cavendish"] = true,
        ["j_turtle_bean"] = true,
        ["j_diet_cola"] = true,
        ["j_popcorn"] = true,
        ["j_ramen"] = true,
        ["j_selzer"] = true
    },
})

SMODS.ObjectType({
    key = "galaxysf_galaxysf_jokers",
    cards = {
        ["j_galaxysf__4"] = true,
        ["j_galaxysf_aaron"] = true,
        ["j_galaxysf_absoluteseal"] = true,
        ["j_galaxysf_allroadsleadtorome"] = true,
        ["j_galaxysf_angel"] = true,
        ["j_galaxysf_anton"] = true,
        ["j_galaxysf_argarthakirk"] = true,
        ["j_galaxysf_athena"] = true,
        ["j_galaxysf_balala"] = true,
        ["j_galaxysf_balman"] = true,
        ["j_galaxysf_barkingspider"] = true,
        ["j_galaxysf_bella"] = true,
        ["j_galaxysf_bendywasalittledevilthing"] = true,
        ["j_galaxysf_benny"] = true,
        ["j_galaxysf_berdly"] = true,
        ["j_galaxysf_bigyahu"] = true,
        ["j_galaxysf_bobbylee"] = true,
        ["j_galaxysf_bricktherat"] = true,
        ["j_galaxysf_bubble"] = true,
        ["j_galaxysf_bubbles"] = true,
        ["j_galaxysf_buttercup"] = true,
        ["j_galaxysf_caine"] = true,
        ["j_galaxysf_cityboy"] = true,
        ["j_galaxysf_craigtucker"] = true,
        ["j_galaxysf_crowbar"] = true,
        ["j_galaxysf_desklady"] = true,
        ["j_galaxysf_diamondpickaxe"] = true,
        ["j_galaxysf_dickhoppin"] = true,
        ["j_galaxysf_dino"] = true,
        ["j_galaxysf_dispenser"] = true,
        ["j_galaxysf_drfreak"] = true,
        ["j_galaxysf_druski"] = true,
        ["j_galaxysf_enrique"] = true,
        ["j_galaxysf_fentmaxxing"] = true,
        ["j_galaxysf_fish"] = true,
        ["j_galaxysf_fishhat"] = true,
        ["j_galaxysf_gabagool"] = true,
        ["j_galaxysf_galaxy"] = true,
        ["j_galaxysf_gamer"] = true,
        ["j_galaxysf_gangle"] = true,
        ["j_galaxysf_gemstonevein"] = true,
        ["j_galaxysf_gengar"] = true,
        ["j_galaxysf_georgeseri"] = true,
        ["j_galaxysf_gir"] = true,
        ["j_galaxysf_gloink"] = true,
        ["j_galaxysf_goldendandelion"] = true,
        ["j_galaxysf_goldenfever"] = true,
        ["j_galaxysf_goodnoodleseveryday"] = true,
        ["j_galaxysf_goofy"] = true,
        ["j_galaxysf_gordonfreeman"] = true,
        ["j_galaxysf_gothamchessthumbnail"] = true,
        ["j_galaxysf_greenbeanwatchumean"] = true,
        ["j_galaxysf_greninja"] = true,
        ["j_galaxysf_gus"] = true,
        ["j_galaxysf_hoodtrapremix"] = true,
        ["j_galaxysf_howdoicloseundertale"] = true,
        ["j_galaxysf_ijustboughtmorelandinthemetaverse"] = true,
        ["j_galaxysf_imnotthatthirstyanymore"] = true,
        ["j_galaxysf_isthatthegrimreaper"] = true,
        ["j_galaxysf_ivyperezly"] = true,
        ["j_galaxysf_jax"] = true,
        ["j_galaxysf_jeff"] = true,
        ["j_galaxysf_joemetridesh"] = true,
        ["j_galaxysf_jokermaker"] = true,
        ["j_galaxysf_jokertype7"] = true,
        ["j_galaxysf_kakegurui"] = true,
        ["j_galaxysf_kinger2"] = true,
        ["j_galaxysf_kris"] = true,
        ["j_galaxysf_lancer"] = true,
        ["j_galaxysf_lemimir"] = true,
        ["j_galaxysf_lollipop"] = true,
        ["j_galaxysf_louis"] = true,
        ["j_galaxysf_luna"] = true,
        ["j_galaxysf_marketplayer"] = true,
        ["j_galaxysf_mewhenisteponthelego"] = true,
        ["j_galaxysf_midastouch"] = true,
        ["j_galaxysf_milk"] = true,
        ["j_galaxysf_minimus"] = true,
        ["j_galaxysf_minisentry"] = true,
        ["j_galaxysf_mmmbobby"] = true,
        ["j_galaxysf_moe"] = true,
        ["j_galaxysf_moose"] = true,
        ["j_galaxysf_mooseman"] = true,
        ["j_galaxysf_mrbeast"] = true,
        ["j_galaxysf_murphyobv"] = true,
        ["j_galaxysf_neverpostavideoagain"] = true,
        ["j_galaxysf_noelle"] = true,
        ["j_galaxysf_nothing"] = true,
        ["j_galaxysf_pairofshoes"] = true,
        ["j_galaxysf_patches"] = true,
        ["j_galaxysf_peaches"] = true,
        ["j_galaxysf_pear"] = true,
        ["j_galaxysf_pennywise"] = true,
        ["j_galaxysf_pikachu"] = true,
        ["j_galaxysf_pokeball"] = true,
        ["j_galaxysf_pomni"] = true,
        ["j_galaxysf_poopmanoffical"] = true,
        ["j_galaxysf_princerupertsdrop"] = true,
        ["j_galaxysf_punchingbabiesinpublicprank"] = true,
        ["j_galaxysf_rabbibillclinton"] = true,
        ["j_galaxysf_ragatha"] = true,
        ["j_galaxysf_rainfall"] = true,
        ["j_galaxysf_ralsei"] = true,
        ["j_galaxysf_rat"] = true,
        ["j_galaxysf_rocklobster"] = true,
        ["j_galaxysf_ronaldmcdonald"] = true,
        ["j_galaxysf_schmeegle"] = true,
        ["j_galaxysf_scouttf2"] = true,
        ["j_galaxysf_scratchy"] = true,
        ["j_galaxysf_shadow"] = true,
        ["j_galaxysf_skibiditoiletorcreeper"] = true,
        ["j_galaxysf_somebodygamblingonavapefilmedonavape"] = true,
        ["j_galaxysf_son"] = true,
        ["j_galaxysf_sonic"] = true,
        ["j_galaxysf_sothishappened"] = true,
        ["j_galaxysf_soyjack"] = true,
        ["j_galaxysf_squidward"] = true,
        ["j_galaxysf_squirtle"] = true,
        ["j_galaxysf_sumo"] = true,
        ["j_galaxysf_susie"] = true,
        ["j_galaxysf_thatonekidwhoruinseveryjoke"] = true,
        ["j_galaxysf_themenstrualcycle"] = true,
        ["j_galaxysf_tiger"] = true,
        ["j_galaxysf_tonysaprano"] = true,
        ["j_galaxysf_tweektweak"] = true,
        ["j_galaxysf_uncledane"] = true,
        ["j_galaxysf_videokilledtheradiostar"] = true,
        ["j_galaxysf_vro"] = true,
        ["j_galaxysf_what"] = true,
        ["j_galaxysf_worldslargestlazer"] = true,
        ["j_galaxysf_youngsheldon"] = true,
        ["j_galaxysf_zencartman"] = true,
        ["j_galaxysf_zero"] = true,
        ["j_galaxysf_zooble"] = true
    },
})

SMODS.ObjectType({
    key = "galaxysf_galaxysf_pets",
    cards = {
        ["j_galaxysf_aaron"] = true,
        ["j_galaxysf_angel"] = true,
        ["j_galaxysf_athena"] = true,
        ["j_galaxysf_bella"] = true,
        ["j_galaxysf_benny"] = true,
        ["j_galaxysf_buttercup"] = true,
        ["j_galaxysf_dino"] = true,
        ["j_galaxysf_georgeseri"] = true,
        ["j_galaxysf_gus"] = true,
        ["j_galaxysf_louis"] = true,
        ["j_galaxysf_luna"] = true,
        ["j_galaxysf_moose"] = true,
        ["j_galaxysf_peaches"] = true,
        ["j_galaxysf_scratchy"] = true,
        ["j_galaxysf_shadow"] = true,
        ["j_galaxysf_sonic"] = true,
        ["j_galaxysf_tiger"] = true,
        ["j_galaxysf_zero"] = true
    },
})

SMODS.ObjectType({
    key = "galaxysf_galaxysf_godlys",
    cards = {
        ["j_galaxysf_adrianshepard"] = true,
        ["j_galaxysf_gman"] = true,
        ["j_galaxysf_hubert"] = true,
        ["j_galaxysf_millennialburger"] = true,
        ["j_galaxysf_rofflelite"] = true,
        ["j_galaxysf_saxtonhale"] = true,
        ["j_galaxysf_supjew"] = true,
        ["j_galaxysf_truejollyjoker"] = true,
        ["j_galaxysf_washeewashee"] = true,
        ["j_galaxysf_weirdgamer"] = true,
        ["j_galaxysf_whatsappinvincible"] = true
    },
})

SMODS.ObjectType({
    key = "galaxysf_galaxysf_darkener",
    cards = {
        ["j_galaxysf_berdly"] = true,
        ["j_galaxysf_kris"] = true,
        ["j_galaxysf_lancer"] = true,
        ["j_galaxysf_noelle"] = true,
        ["j_galaxysf_ralsei"] = true,
        ["j_galaxysf_susie"] = true
    },
})

SMODS.ObjectType({
    key = "galaxysf_galaxysf_tadc",
    cards = {
        ["j_galaxysf_bubble"] = true,
        ["j_galaxysf_gangle"] = true,
        ["j_galaxysf_jax"] = true,
        ["j_galaxysf_kinger2"] = true,
        ["j_galaxysf_pomni"] = true,
        ["j_galaxysf_ragatha"] = true,
        ["j_galaxysf_zooble"] = true
    },
})

SMODS.ObjectType({
    key = "galaxysf_galaxysf_mythicals",
    cards = {
        ["j_galaxysf_chocolatemilk"] = true,
        ["j_galaxysf_cybron"] = true,
        ["j_galaxysf_lockedinalien"] = true,
        ["j_galaxysf_nightmare"] = true,
        ["j_galaxysf_ultraperkeo"] = true
    },
})


SMODS.current_mod.optional_features = function()
    return {
        cardareas = {} 
    }
end