
SMODS.Booster {
    key = 'galaxys_mega_boosta',
    loc_txt = {
        name = "Galaxys Mega Boosta",
        text = {
            [1] = 'A {C:purple}custom{} booster pack with {C:blue}unique{} cards.'
        },
        group_name = "galaxysf_boosters"
    },
    config = { extra = 5, choose = 1 },
    cost = 10,
    weight = 6.15,
    atlas = "CustomBoosters",
    pos = { x = 0, y = 0 },
    group_key = "galaxysf_boosters",
    discovered = true,
    loc_vars = function(self, info_queue, card)
        local cfg = (card and card.ability) or self.config
        return {
            vars = { cfg.choose, cfg.extra }
        }
    end,
    create_card = function(self, card, i)
        local weights = {
            4.55,
            3.9,
            2.6,
            0.05
        }
        local total_weight = 0
        for _, weight in ipairs(weights) do
            total_weight = total_weight + weight
        end
        local random_value = pseudorandom('galaxysf_galaxys_mega_boosta_card') * total_weight
        local cumulative_weight = 0
        local selected_index = 1
        for j, weight in ipairs(weights) do
            cumulative_weight = cumulative_weight + weight
            if random_value <= cumulative_weight then
                selected_index = j
                break
            end
        end
        if selected_index == 1 then
            return {
                set = "galaxysf_galaxysf_jokers",
                rarity = "Common",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "galaxysf_galaxys_mega_boosta"
            }
        elseif selected_index == 2 then
            return {
                set = "galaxysf_galaxysf_jokers",
                rarity = "Uncommon",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "galaxysf_galaxys_mega_boosta"
            }
        elseif selected_index == 3 then
            return {
                set = "galaxysf_galaxysf_jokers",
                rarity = "Rare",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "galaxysf_galaxys_mega_boosta"
            }
        elseif selected_index == 4 then
            return {
                set = "galaxysf_galaxysf_jokers",
                rarity = "galaxysf_godly",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "galaxysf_galaxys_mega_boosta"
            }
        end
    end,
    particles = function(self)
        -- No particles for joker packs
        end,
    }
    
    
    SMODS.Booster {
        key = 'pet_booster_pack',
        loc_txt = {
            name = "Pet Booster Pack",
            text = {
                [1] = 'Contains Pet Cards'
            },
            group_name = "galaxysf_boosters"
        },
        config = { extra = 5, choose = 1 },
        cost = 5,
        weight = 7.15,
        atlas = "CustomBoosters",
        pos = { x = 1, y = 0 },
        group_key = "galaxysf_boosters",
        discovered = true,
        loc_vars = function(self, info_queue, card)
            local cfg = (card and card.ability) or self.config
            return {
                vars = { cfg.choose, cfg.extra }
            }
        end,
        create_card = function(self, card, i)
            return {
                set = "galaxysf_galaxysf_pets",
                rarity = "galaxysf_pet",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "galaxysf_pet_booster_pack"
            }
        end,
        particles = function(self)
            -- No particles for joker packs
            end,
        }
        