
SMODS.Seal {
    key = 'freakyseal',
    pos = { x = 0, y = 0 },
    config = {
        extra = {
            dollars0 = 1,
            xmult0 = 1.25
        }
    },
    badge_colour = HEX('000000'),
    loc_txt = {
        name = 'Freaky Seal',
        label = 'Freaky Seal',
        text = {
            [1] = '{C:red}-1$ {}But earn {X:red,C:white}X1.25{} Mult on each played card'
        }
    },
    atlas = 'CustomSeals',
    unlocked = true,
    discovered = true,
    no_collection = false,
    calculate = function(self, card, context)
        if context.main_scoring and context.cardarea == G.play then
            return {
                
                func = function()
                    
                    local current_dollars = G.GAME.dollars
                    local target_dollars = G.GAME.dollars - 1
                    local dollar_value = target_dollars - current_dollars
                    ease_dollars(dollar_value)
                    card_eval_status_text(card, 'extra', nil, nil, nil, {message = "-"..tostring(1), colour = G.C.MONEY})
                    return true
                end,
                extra = {
                    Xmult = 1.25
                }
            }
        end
    end
}