
SMODS.Seal {
    key = 'chudseal',
    pos = { x = 1, y = 0 },
    config = {
        extra = {
            odds = 2,
            odds2 = 4,
            odds3 = 8,
            dollars0 = 2,
            dollars = 2,
            xmult0 = 3,
            dollars2 = 10
        }
    },
    badge_colour = HEX('FF6B6B'),
    loc_txt = {
        name = 'Chud Seal',
        label = 'Chud Seal',
        text = {
            [1] = '1 in 2 Chance for {C:money}2${}',
            [2] = '',
            [3] = '1 in 2 Chance for {C:red}-2${}',
            [4] = '',
            [5] = '1 in 4 for {X:red,C:white}X3{} Mult',
            [6] = '',
            [7] = '1 in 8 Chance For{C:money} 10${}'
        }
    },
    atlas = 'CustomSeals',
    unlocked = true,
    discovered = true,
    no_collection = false,
    loc_vars = function(self, info_queue, card)
        return {vars = {}}
    end,
    calculate = function(self, card, context)
        if context.main_scoring and context.cardarea == G.play then
            if SMODS.pseudorandom_probability(card, 'group_0_c44d3bff', 1, card.ability.seal.extra.odds, 'j_galaxysf_chudseal', false) then
                SMODS.calculate_effect({
                    func = function()
                        
                        local current_dollars = G.GAME.dollars
                        local target_dollars = G.GAME.dollars - 2
                        local dollar_value = target_dollars - current_dollars
                        ease_dollars(dollar_value)
                        card_eval_status_text(card, 'extra', nil, nil, nil, {message = "-"..tostring(2), colour = G.C.MONEY})
                        return true
                    end}, card)
                end
                if SMODS.pseudorandom_probability(card, 'group_1_c9123711', 1, card.ability.seal.extra.odds, 'j_galaxysf_chudseal', false) then
                    SMODS.calculate_effect({
                        func = function()
                            
                            local current_dollars = G.GAME.dollars
                            local target_dollars = G.GAME.dollars + 2
                            local dollar_value = target_dollars - current_dollars
                            ease_dollars(dollar_value)
                            card_eval_status_text(card, 'extra', nil, nil, nil, {message = "+"..tostring(2), colour = G.C.MONEY})
                            return true
                        end}, card)
                    end
                    if SMODS.pseudorandom_probability(card, 'group_2_57f81b79', 1, card.ability.seal.extra.odds2, 'j_galaxysf_chudseal', false) then
                        SMODS.calculate_effect({Xmult = 3}, card)
                    end
                    if SMODS.pseudorandom_probability(card, 'group_3_9531a71a', 1, card.ability.seal.extra.odds3, 'j_galaxysf_chudseal', false) then
                        SMODS.calculate_effect({
                            func = function()
                                
                                local current_dollars = G.GAME.dollars
                                local target_dollars = G.GAME.dollars + 10
                                local dollar_value = target_dollars - current_dollars
                                ease_dollars(dollar_value)
                                card_eval_status_text(card, 'extra', nil, nil, nil, {message = "+"..tostring(10), colour = G.C.MONEY})
                                return true
                            end}, card)
                        end
                    end
                end
            }