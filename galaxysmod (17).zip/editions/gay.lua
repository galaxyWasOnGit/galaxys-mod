
SMODS.Shader({ key = 'monochrome', path = 'monochrome.fs' })

SMODS.Edition {
    key = 'gay',
    shader = 'monochrome',
    config = {
        extra = {
            xmult0 = 1.25
        }
    },
    in_shop = true,
    weight = 3.5,
    extra_cost = 4,
    apply_to_float = false,
    disable_shadow = false,
    disable_base_shader = false,
    loc_txt = {
        name = 'Gay',
        label = 'Gay',
        text = {
            [1] = '{X:red,C:white}X1.25{} Mult'
        }
    },
    unlocked = true,
    discovered = true,
    no_collection = false,
    get_weight = function(self)
        return G.GAME.edition_rate * self.weight
    end,
    
    calculate = function(self, card, context)
        if context.pre_joker or (context.main_scoring and context.cardarea == G.play) then
            return {
                Xmult = 1.25
            }
        end
    end
}