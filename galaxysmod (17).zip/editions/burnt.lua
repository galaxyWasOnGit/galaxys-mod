
SMODS.Shader({ key = 'ionized', path = 'ionized.fs' })

SMODS.Edition {
    key = 'burnt',
    shader = 'ionized',
    config = {
        extra = {
            xmult0 = 0.75
        }
    },
    in_shop = true,
    weight = 13.5,
    apply_to_float = true,
    badge_colour = HEX('422c00'),
    sound = { sound = "ambientFire1", per = 1.2, vol = 0.4 },
    disable_shadow = false,
    disable_base_shader = false,
    loc_txt = {
        name = 'Burnt',
        label = 'Burnt',
        text = {
            [1] = '{X:red,C:white}X0.75{} Mult'
        }
    },
    unlocked = true,
    discovered = true,
    no_collection = false,
    get_weight = function(self)
        return G.GAME.edition_rate * self.weight
    end,
    
    calculate = function(self, card, context)
        if context.pre_joker or (context.main_scoring and context.cardarea == G.play) then
            return {
                Xmult = 0.75
            }
        end
    end
}