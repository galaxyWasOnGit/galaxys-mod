SMODS.Rarity {
    key = "godly",
    pools = {
        ["Joker"] = true
    },
    default_weight = 0,
    badge_colour = HEX('000000'),
    loc_txt = {
        name = "GODLY"
    },
    get_weight = function(self, weight, object_type)
        return weight
    end,
}

SMODS.Rarity {
    key = "pet",
    pools = {
        ["Joker"] = true
    },
    default_weight = 0.35,
    badge_colour = HEX('3a8331'),
    loc_txt = {
        name = "Pet"
    },
    get_weight = function(self, weight, object_type)
        return weight
    end,
}

SMODS.Rarity {
    key = "dev",
    pools = {
        ["Joker"] = true
    },
    default_weight = 0,
    badge_colour = HEX('5c5c5c'),
    loc_txt = {
        name = "Dev"
    },
    get_weight = function(self, weight, object_type)
        return weight
    end,
}

SMODS.Rarity {
    key = "mythical",
    pools = {
        ["Joker"] = true
    },
    default_weight = 0,
    badge_colour = HEX('ff59ea'),
    loc_txt = {
        name = "Mythical"
    },
    get_weight = function(self, weight, object_type)
        return weight
    end,
}

SMODS.Rarity {
    key = "trading_card",
    pools = {
        ["Joker"] = true
    },
    default_weight = 0.15,
    badge_colour = HEX('979797'),
    loc_txt = {
        name = "Trading Card"
    },
    get_weight = function(self, weight, object_type)
        return weight
    end,
}