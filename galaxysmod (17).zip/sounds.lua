SMODS.Sound{
    key="Wheredoeshework",
    path="Wheredoeshework.ogg",
    pitch=0.7,
    volume=0.6,
}

SMODS.Sound{
    key="yourabitdeaf",
    path="yourabitdeaf.ogg",
    pitch=0.7,
    volume=0.6,
}

SMODS.Sound{
    key="Barkingspider",
    path="Barkingspider.ogg",
    pitch=0.7,
    volume=7,
}

SMODS.Sound{
    key="hemmy",
    path="hemmy.ogg",
    pitch=0.7,
    volume=0.6,
}

SMODS.Sound{
    key="standup",
    path="standup.ogg",
    pitch=0.7,
    volume=0.6,
}

SMODS.Sound{
    key="pattycake",
    path="pattycake.ogg",
    pitch=0.7,
    volume=0.6,
}

SMODS.Sound{
    key="Uncledaneintro",
    path="Uncledaneintro.ogg",
    pitch=0.7,
    volume=0.6,
}

SMODS.Sound{
    key="uncledanedispenser",
    path="uncledanedispenser.ogg",
    pitch=0.7,
    volume=0.6,
}

SMODS.Sound{
    key="uncledanesentry",
    path="uncledanesentry.ogg",
    pitch=0.7,
    volume=0.6,
}

SMODS.Sound{
    key="enrique",
    path="enrique.ogg",
    pitch=0.7,
    volume=1.3,
}

SMODS.Sound{
    key="landdownunder",
    path="landdownunder.ogg",
    pitch=0.7,
    volume=0.4,
}

SMODS.Sound{
    key="leekeybum",
    path="leekeybum.ogg",
    pitch=0.7,
    volume=0.6,
}

SMODS.Sound{
    key="Motion",
    path="Motion.ogg",
    pitch=0.7,
    volume=0.6,
}

SMODS.Sound{
    key="nah",
    path="nah.ogg",
    pitch=0.7,
    volume=0.6,
}

SMODS.Sound{
    key="Gman",
    path="Gman.ogg",
    pitch=0.7,
    volume=0.6,
}

SMODS.Sound{
    key="goofy",
    path="goofy.ogg",
    pitch=0.7,
    volume=0.6,
}

SMODS.Sound{
    key="uncle",
    path="uncle.ogg",
    pitch=0.7,
    volume=0.6,
}

SMODS.Sound{
    key="laminated",
    path="laminated.ogg",
    pitch=0.7,
    volume=0.6,
}