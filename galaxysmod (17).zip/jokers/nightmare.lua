
SMODS.Joker{ --Nightmare
    key = "nightmare",
    config = {
        extra = {
            xmult0 = 7.5,
            xmult = 7.5
        }
    },
    loc_txt = {
        ['name'] = 'Nightmare',
        ['text'] = {
            [1] = '{X:red,C:white}X7.5{} Mult On Every Scored {C:clubs}Clubs{} And {C:spades}Spades{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 4,
        y = 8
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 35,
    rarity = "galaxysf_mythical",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["galaxysf_galaxysf_mythicals"] = true },
    in_pool = function(self, args)
        return (
            not args 
            or args.source ~= 'sho' 
            or args.source == 'buf' or args.source == 'jud' or args.source == 'rif' or args.source == 'rta' or args.source == 'sou' or args.source == 'uta' or args.source == 'wra'
        )
        and true
    end,
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if context.other_card:is_suit("Clubs") then
                return {
                    Xmult = 7.5
                }
            elseif context.other_card:is_suit("Spades") then
                return {
                    Xmult = 7.5
                }
            end
        end
    end
}