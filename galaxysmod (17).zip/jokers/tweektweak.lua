
SMODS.Joker{ --Tweek Tweak
    key = "tweektweak",
    config = {
        extra = {
            xmult0 = 5.5
        }
    },
    loc_txt = {
        ['name'] = 'Tweek Tweak',
        ['text'] = {
            [1] = '{X:red,C:white}X5.5{} Mult on Aces Of Hearts'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 9,
        y = 7
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["galaxysf_galaxysf_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if (context.other_card:is_suit("Hearts") and context.other_card:get_id() == 14) then
                return {
                    Xmult = 5.5
                }
            end
        end
    end
}