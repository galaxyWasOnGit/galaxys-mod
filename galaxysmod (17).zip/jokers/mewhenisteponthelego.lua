
SMODS.Joker{ --Me when i step on the lego
    key = "mewhenisteponthelego",
    config = {
        extra = {
            xmult0 = 1.75
        }
    },
    loc_txt = {
        ['name'] = 'Me when i step on the lego',
        ['text'] = {
            [1] = '{X:red,C:white}X1.75{} Mult on {C:hearts}Heart{} Cards'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 1,
        y = 9
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["galaxysf_galaxysf_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if context.other_card:is_suit("Hearts") then
                return {
                    Xmult = 1.75
                }
            end
        end
    end
}