
SMODS.Joker{ --JokerType_7
    key = "jokertype7",
    config = {
        extra = {
            xmult0 = 0.3
        }
    },
    loc_txt = {
        ['name'] = 'JokerType_7',
        ['text'] = {
            [1] = 'fuck you: steals {X:red,C:white}X0.3 {} Mult'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 3,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 1,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["galaxysf_galaxysf_jokers"] = true },
    
    set_ability = function(self, card, initial)
        card:set_eternal(true)
    end,
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            return {
                Xmult = 0.3
            }
        end
    end
}