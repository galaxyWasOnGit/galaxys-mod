
SMODS.Joker{ --Saxton Hale
    key = "saxtonhale",
    config = {
        extra = {
            xmult0 = 999
        }
    },
    loc_txt = {
        ['name'] = 'Saxton Hale',
        ['text'] = {
            [1] = '{X:red,C:white}X999{} Mult On Each Card'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 2,
        y = 7
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 500,
    rarity = "galaxysf_godly",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["galaxysf_galaxysf_godlys"] = true },
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            return {
                Xmult = 999
            }
        end
    end
}