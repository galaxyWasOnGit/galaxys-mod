
SMODS.Joker{ --Shadow
    key = "shadow",
    config = {
        extra = {
            xmult0 = 2.5
        }
    },
    loc_txt = {
        ['name'] = 'Shadow',
        ['text'] = {
            [1] = '{X:red,C:white}X2.5{} Mult If you have any other pet card',
            [2] = '',
            [3] = '(Bubbles\'s Cat)'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 5,
        y = 6
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = "galaxysf_pet",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["galaxysf_galaxysf_jokers"] = true, ["galaxysf_galaxysf_pets"] = true },
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if (function()
                local count = 0
                for _, joker_owned in pairs(G.jokers.cards or {}) do
                    if joker_owned.config.center.rarity == "galaxysf_pet" then
                        count = count + 1
                    end
                end
                return to_big(count) > to_big(1)
            end)() then
                return {
                    Xmult = 2.5
                }
            end
        end
    end
}