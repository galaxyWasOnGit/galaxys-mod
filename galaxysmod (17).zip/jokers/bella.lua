
SMODS.Joker{ --Bella
    key = "bella",
    config = {
        extra = {
            xchips0 = 2,
            xmult0 = 2
        }
    },
    loc_txt = {
        ['name'] = 'Bella',
        ['text'] = {
            [1] = '{X:blue,C:white}X2{} Chips And {X:red,C:white}X2{} Mult',
            [2] = '',
            [3] = '(Galaxy\'s Cat)'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 7,
        y = 7
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = "galaxysf_pet",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["galaxysf_galaxysf_jokers"] = true, ["galaxysf_galaxysf_pets"] = true },
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                x_chips = 2,
                extra = {
                    Xmult = 2
                }
            }
        end
    end
}