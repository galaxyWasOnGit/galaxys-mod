
SMODS.Joker{ --im not that thirsty anymore
    key = "imnotthatthirstyanymore",
    config = {
        extra = {
            xmult0 = 2
        }
    },
    loc_txt = {
        ['name'] = 'im not that thirsty anymore',
        ['text'] = {
            [1] = 'Play A {C:enhanced} #1# {} For {X:red,C:white}X2{} Mult',
            [2] = '',
            [3] = '(Changes Every Round)'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 2,
        y = 12
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["galaxysf_galaxysf_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {localize((G.GAME.current_round.drinksuit_card or {}).suit or 'Spades', 'suits_singular')}, colours = {G.C.SUITS[(G.GAME.current_round.drinksuit_card or {}).suit or 'Spades']}}
    end,
    
    set_ability = function(self, card, initial)
        G.GAME.current_round.drinksuit_card = { suit = 'Spades' }
    end,
    
    calculate = function(self, card, context)
        if context.first_hand_drawn  then
            if G.playing_cards then
                local valid_drinksuit_cards = {}
                for _, v in ipairs(G.playing_cards) do
                    if not SMODS.has_no_suit(v) then
                        valid_drinksuit_cards[#valid_drinksuit_cards + 1] = v
                    end
                end
                if valid_drinksuit_cards[1] then
                    local drinksuit_card = pseudorandom_element(valid_drinksuit_cards, pseudoseed('drinksuit' .. G.GAME.round_resets.ante))
                    G.GAME.current_round.drinksuit_card.suit = drinksuit_card.base.suit
                end
            end
        end
        if context.individual and context.cardarea == G.play  then
            if context.other_card:is_suit(G.GAME.current_round.drinksuit_card.suit) then
                return {
                    Xmult = 2
                }
            end
        end
    end
}