
SMODS.Joker{ --Cybron
    key = "cybron",
    config = {
        extra = {
            xchips0 = 3,
            xmult0 = 3
        }
    },
    loc_txt = {
        ['name'] = 'Cybron',
        ['text'] = {
            [1] = 'Gives {X:red,C:white}X5{} Mult and {X:blue,C:white}X3{} Chips on each card'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 35,
    rarity = "galaxysf_mythical",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["galaxysf_galaxysf_mythicals"] = true },
    in_pool = function(self, args)
        return (
            not args 
            or args.source ~= 'sho' 
            or args.source == 'buf' or args.source == 'jud' or args.source == 'rif' or args.source == 'rta' or args.source == 'sou' or args.source == 'uta' or args.source == 'wra'
        )
        and true
    end,
    
    set_ability = function(self, card, initial)
        card:set_edition("e_polychrome", true)
    end,
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            return {
                x_chips = 3,
                extra = {
                    Xmult = 3
                }
            }
        end
    end
}