
SMODS.Joker{ --Anton
    key = "anton",
    config = {
        extra = {
            odds = 3,
            xmult0 = 2
        }
    },
    loc_txt = {
        ['name'] = 'Anton',
        ['text'] = {
            [1] = '{C:green}#1# in 3{} Chance For {X:red,C:white}X2{} Mult'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 4,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 9,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["galaxysf_galaxysf_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_galaxysf_anton') 
        return {vars = {new_numerator, new_denominator}}
    end,
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if true then
                if SMODS.pseudorandom_probability(card, 'group_0_6354aa68', 1, card.ability.extra.odds, 'j_galaxysf_anton', false) then
                    G.E_MANAGER:add_event(Event({
                        func = function()
                            play_sound("galaxysf_Wheredoeshework")
                            
                            return true
                        end,
                    }))
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Where Does He Work?", colour = G.C.WHITE})
                    SMODS.calculate_effect({Xmult = 2}, card)
                end
            end
        end
    end
}