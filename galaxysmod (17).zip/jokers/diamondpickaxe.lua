
SMODS.Joker{ --Diamond Pickaxe
    key = "diamondpickaxe",
    config = {
        extra = {
            diamondpickaxemult = 0
        }
    },
    loc_txt = {
        ['name'] = 'Diamond Pickaxe',
        ['text'] = {
            [1] = 'Destroys scored {C:attention}Gold{} and {C:attention}Steel{} Cards and gain {X:red,C:white}X0.5{} Mult',
            [2] = '',
            [3] = '(Currently: {X:red,C:white} X#1# {} Mult'
            },
            ['unlock'] = {
                [1] = 'Unlocked by default.'
            }
        },
        pos = {
            x = 6,
            y = 11
        },
        display_size = {
            w = 71 * 1, 
            h = 95 * 1
        },
        cost = 6,
        rarity = 3,
        blueprint_compat = true,
        eternal_compat = true,
        perishable_compat = true,
        unlocked = true,
        discovered = true,
        atlas = 'CustomJokers',
        pools = { ["galaxysf_galaxysf_jokers"] = true },
        
        loc_vars = function(self, info_queue, card)
            
            return {vars = {card.ability.extra.diamondpickaxemult}}
        end,
        
        calculate = function(self, card, context)
            if context.destroy_card and context.destroy_card.should_destroy  then
                return { remove = true }
            end
            if context.individual and context.cardarea == G.play  then
                context.other_card.should_destroy = false
                if SMODS.get_enhancements(context.other_card)["m_gold"] == true then
                    context.other_card.should_destroy = true
                    card.ability.extra.diamondpickaxemult = (card.ability.extra.diamondpickaxemult) + 0.5
                    return {
                        message = "Destroyed!"
                    }
                end
            end
            if context.cardarea == G.jokers and context.joker_main  then
                return {
                    Xmult = card.ability.extra.diamondpickaxemult
                }
            end
        end
    }