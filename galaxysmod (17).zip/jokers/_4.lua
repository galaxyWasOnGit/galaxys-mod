
SMODS.Joker{ --4
    key = "_4",
    config = {
        extra = {
            hand_size0 = 4
        }
    },
    loc_txt = {
        ['name'] = '4',
        ['text'] = {
            [1] = 'Sell this card to gain {C:attention}+4{} Hand size'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 6,
        y = 4
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["galaxysf_galaxysf_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.selling_self  then
            return {
                
                func = function()
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(4).." Hand Limit", colour = G.C.BLUE})
                    
                    G.hand:change_size(4)
                    return true
                end
            }
        end
    end
}