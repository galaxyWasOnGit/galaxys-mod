
SMODS.Joker{ --Rat
    key = "rat",
    config = {
        extra = {
            mult0 = 4,
            odds = 4
        }
    },
    loc_txt = {
        ['name'] = 'Rat',
        ['text'] = {
            [1] = '{C:green}#1# In 4{} Chance to duplicate itself as a negative',
            [2] = '',
            [3] = '{C:red}+3{} Mult',
            [4] = '',
            [5] = '(Image By Giraffevibes)'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 4,
        y = 11
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["galaxysf_galaxysf_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_galaxysf_rat') 
        return {vars = {new_numerator, new_denominator}}
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if true then
                return {
                    mult = 4
                    ,
                    func = function()
                        if SMODS.pseudorandom_probability(card, 'group_0_7d7a9af4', 1, card.ability.extra.odds, 'j_galaxysf_rat', false) then
                            local created_joker = false
                            if #G.jokers.cards + G.GAME.joker_buffer < G.jokers.config.card_limit then
                                created_joker = true
                                G.GAME.joker_buffer = G.GAME.joker_buffer + 1
                                G.E_MANAGER:add_event(Event({
                                    func = function()
                                        local joker_card = SMODS.add_card({ set = 'Joker', key = 'j_galaxysf_rat' })
                                        if joker_card then
                                            joker_card:set_edition("e_negative", true)
                                            
                                        end
                                        G.GAME.joker_buffer = 0
                                        return true
                                    end
                                }))
                            end
                            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = created_joker and localize('k_plus_joker') or nil, colour = G.C.BLUE})
                        end
                        return true
                    end
                }
            end
        end
    end
}