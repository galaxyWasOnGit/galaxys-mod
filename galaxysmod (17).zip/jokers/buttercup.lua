
SMODS.Joker{ --Buttercup
    key = "buttercup",
    config = {
        extra = {
            xmult0 = 1.5
        }
    },
    loc_txt = {
        ['name'] = 'Buttercup',
        ['text'] = {
            [1] = '{X:red,C:white}X1.5{} Mult For {C:attention}Gold{} Cards Played',
            [2] = '',
            [3] = '(He Thinks its butter)',
            [4] = '',
            [5] = '(Galaxy\'s Cat)'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 6
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = "galaxysf_pet",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["galaxysf_galaxysf_jokers"] = true, ["galaxysf_galaxysf_pets"] = true },
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if SMODS.get_enhancements(context.other_card)["m_gold"] == true then
                return {
                    Xmult = 1.5
                }
            end
        end
    end
}