
SMODS.Joker{ --HOW DO I CLOSE UNDERTALE
    key = "howdoicloseundertale",
    config = {
        extra = {
            mult0 = 35
        }
    },
    loc_txt = {
        ['name'] = 'HOW DO I CLOSE UNDERTALE',
        ['text'] = {
            [1] = '{C:red}+35{} Mult On Each {C:hearts}Heart{} Aces Played'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 12
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["galaxysf_galaxysf_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if context.other_card:is_suit("Hearts") then
                return {
                    mult = 35
                }
            end
        end
    end
}