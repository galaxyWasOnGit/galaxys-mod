
SMODS.Joker{ --Rabbi Bill Clinton
    key = "rabbibillclinton",
    config = {
        extra = {
            xmult0 = 10
        }
    },
    loc_txt = {
        ['name'] = 'Rabbi Bill Clinton',
        ['text'] = {
            [1] = 'If Big Yahu Is Selected Gives {X:red,C:white}X10{} Mult'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 8,
        y = 5
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["galaxysf_galaxysf_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if #G.jokers.highlighted > 0 and G.jokers.highlighted[1].config.center.key == "j_galaxysf_bigyahu" then
                return {
                    Xmult = 10
                }
            end
        end
    end
}