
SMODS.Joker{ --Scratchy
    key = "scratchy",
    config = {
        extra = {
            chips0 = 100,
            mult0 = 25
        }
    },
    loc_txt = {
        ['name'] = 'Scratchy',
        ['text'] = {
            [1] = '{C:blue}+100{} Chips {C:red}+25{} Mult',
            [2] = '',
            [3] = '(Galaxy\'s Cat)'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 8,
        y = 7
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = "galaxysf_pet",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["galaxysf_galaxysf_jokers"] = true, ["galaxysf_galaxysf_pets"] = true },
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                chips = 100,
                extra = {
                    mult = 25
                }
            }
        end
    end
}