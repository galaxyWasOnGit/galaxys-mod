
SMODS.Joker{ --Zen Cartman
    key = "zencartman",
    config = {
        extra = {
            odds = 3,
            xmult0 = 2.5
        }
    },
    loc_txt = {
        ['name'] = 'Zen Cartman',
        ['text'] = {
            [1] = '{C:green}#1# in 3{} Chance to {X:red,C:white}X2.5{} Mult a Played Card'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 10
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 10,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["galaxysf_galaxysf_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_galaxysf_zencartman') 
        return {vars = {new_numerator, new_denominator}}
    end,
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if true then
                if SMODS.pseudorandom_probability(card, 'group_0_d77af34b', 1, card.ability.extra.odds, 'j_galaxysf_zencartman', false) then
                    SMODS.calculate_effect({Xmult = 2.5}, card)
                end
            end
        end
    end
}