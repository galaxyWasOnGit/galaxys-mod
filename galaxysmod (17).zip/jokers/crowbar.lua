
SMODS.Joker{ --Crowbar
    key = "crowbar",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'Crowbar',
        ['text'] = {
            [1] = 'A Joker With {X:enhanced,C:white}Ancient{} Power',
            [2] = '',
            [3] = 'Pair with gordon freeman for {X:spectral,C:white}True{} Power'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 1,
        y = 11
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["galaxysf_galaxysf_jokers"] = true }
}