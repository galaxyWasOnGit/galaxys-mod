
SMODS.Joker{ --Uncle Dane
    key = "uncledane",
    config = {
        extra = {
            xmult0 = 2.5,
            odds = 4
        }
    },
    loc_txt = {
        ['name'] = 'Uncle Dane',
        ['text'] = {
            [1] = '{X:red,C:white}X2.5{} Mult {C:green}#1# in 4{} chance to bulld a sentry',
            [2] = '',
            [3] = '{C:green}#1# in 4{} chance to build  a dispenser'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 1,
        y = 2
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 10,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["galaxysf_galaxysf_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_galaxysf_uncledane')
        local new_numerator2, new_denominator2 = SMODS.get_probability_vars(card, 1, card.ability.extra.odds2, 'j_galaxysf_uncledane')
        return {vars = {new_numerator, new_denominator, new_numerator2, new_denominator2}}
    end,
    
    calculate = function(self, card, context)
        if context.first_hand_drawn  then
            G.E_MANAGER:add_event(Event({
                func = function()
                    play_sound("galaxysf_Uncledaneintro")
                    
                    return true
                end,
            }))
        end
        if context.cardarea == G.jokers and context.joker_main  then
            if true then
                return {
                    Xmult = 2.5
                    ,
                    func = function()
                        if SMODS.pseudorandom_probability(card, 'group_0_94885292', 1, card.ability.extra.odds, 'j_galaxysf_uncledane', false) then
                            G.E_MANAGER:add_event(Event({
                                func = function()
                                    play_sound("galaxysf_uncledanedispenser")
                                    
                                    return true
                                end,
                            }))
                            local created_joker = false
                            if #G.jokers.cards + G.GAME.joker_buffer < G.jokers.config.card_limit then
                                created_joker = true
                                G.GAME.joker_buffer = G.GAME.joker_buffer + 1
                                G.E_MANAGER:add_event(Event({
                                    func = function()
                                        local joker_card = SMODS.add_card({ set = 'Joker', key = 'j_galaxysf_dispenser' })
                                        if joker_card then
                                            
                                            
                                        end
                                        G.GAME.joker_buffer = 0
                                        return true
                                    end
                                }))
                            end
                            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = created_joker and localize('k_plus_joker') or nil, colour = G.C.BLUE})
                        end
                        if SMODS.pseudorandom_probability(card, 'group_1_4bf347bc', 1, card.ability.extra.odds, 'j_galaxysf_uncledane', false) then
                            G.E_MANAGER:add_event(Event({
                                func = function()
                                    play_sound("galaxysf_uncledanesentry")
                                    
                                    return true
                                end,
                            }))
                            local created_joker = false
                            if #G.jokers.cards + G.GAME.joker_buffer < G.jokers.config.card_limit then
                                created_joker = true
                                G.GAME.joker_buffer = G.GAME.joker_buffer + 1
                                G.E_MANAGER:add_event(Event({
                                    func = function()
                                        local joker_card = SMODS.add_card({ set = 'Joker', key = 'j_galaxysf_minisentry' })
                                        if joker_card then
                                            
                                            
                                        end
                                        G.GAME.joker_buffer = 0
                                        return true
                                    end
                                }))
                            end
                            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = created_joker and localize('k_plus_joker') or nil, colour = G.C.BLUE})
                        end
                        return true
                    end
                }
            end
        end
    end
}