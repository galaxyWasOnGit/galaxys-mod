
SMODS.Joker{ --Fish
    key = "fish",
    config = {
        extra = {
            mult0 = 4
        }
    },
    loc_txt = {
        ['name'] = 'Fish',
        ['text'] = {
            [1] = '{C:red}+4{} Mult',
            [2] = '',
            [3] = '{s:0.8}wait so let me get this straight,{}',
            [4] = '',
            [5] = '{s:0.8}you practically reskinned a normal joker?{}',
            [6] = '',
            [7] = '{s:1.3}yes, yes i did{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 5,
        y = 12
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["galaxysf_galaxysf_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                mult = 4
            }
        end
    end
}