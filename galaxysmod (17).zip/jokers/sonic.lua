
SMODS.Joker{ --Sonic
    key = "sonic",
    config = {
        extra = {
            xchips0 = 1.3,
            chips0 = 25
        }
    },
    loc_txt = {
        ['name'] = 'Sonic',
        ['text'] = {
            [1] = '{X:blue,C:white}X1.3{} Chips and {C:blue}+25{} Chips on each card',
            [2] = '',
            [3] = '(thats a weird looking cat)',
            [4] = '',
            [5] = '(Bubbles\'s Hedgehog)'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 5,
        y = 7
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = "galaxysf_pet",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["galaxysf_galaxysf_jokers"] = true, ["galaxysf_galaxysf_pets"] = true },
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            return {
                x_chips = 1.3,
                extra = {
                    chips = 25,
                    colour = G.C.CHIPS
                }
            }
        end
    end
}