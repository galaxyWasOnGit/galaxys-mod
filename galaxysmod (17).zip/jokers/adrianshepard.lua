
SMODS.Joker{ --Adrian Shepard
    key = "adrianshepard",
    config = {
        extra = {
            xmult0 = 3,
            echips0 = 1.2
        }
    },
    loc_txt = {
        ['name'] = 'Adrian Shepard',
        ['text'] = {
            [1] = 'The {X:spectral,C:white}True{} Warrior Of Black Mesa',
            [2] = '',
            [3] = '({X:red,C:white}X3{} Mult and {X:tarot,C:white}^1.2{} Chips on each Played Card'
            },
            ['unlock'] = {
                [1] = 'Unlocked by default.'
            }
        },
        pos = {
            x = 2,
            y = 11
        },
        display_size = {
            w = 71 * 1, 
            h = 95 * 1
        },
        cost = 500,
        rarity = "galaxysf_godly",
        blueprint_compat = true,
        eternal_compat = true,
        perishable_compat = true,
        unlocked = true,
        discovered = true,
        atlas = 'CustomJokers',
        pools = { ["galaxysf_galaxysf_godlys"] = true },
        in_pool = function(self, args)
            return (
                not args 
                or args.source ~= 'sho' 
                or args.source == 'buf' or args.source == 'jud' or args.source == 'rif' or args.source == 'rta' or args.source == 'sou' or args.source == 'uta' or args.source == 'wra'
            )
            and true
        end,
        
        calculate = function(self, card, context)
            if context.individual and context.cardarea == G.play  then
                return {
                    Xmult = 3,
                    extra = {
                        e_chips = 1.2,
                        colour = G.C.DARK_EDITION
                    }
                }
            end
        end
    }