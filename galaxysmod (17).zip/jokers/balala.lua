
SMODS.Joker{ --Balala
    key = "balala",
    config = {
        extra = {
            xmult0 = 0.05
        }
    },
    loc_txt = {
        ['name'] = 'Balala',
        ['text'] = {
            [1] = '{X:red,C:white}X0.05{} Mult',
            [2] = '',
            [3] = '{C:default}(only true gamers can get gold stake on this card){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 9,
        y = 10
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["galaxysf_galaxysf_jokers"] = true },
    
    set_ability = function(self, card, initial)
        card:set_eternal(true)
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                Xmult = 0.05
            }
        end
    end
}