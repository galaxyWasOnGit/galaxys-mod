
SMODS.Joker{ --Noelle
    key = "noelle",
    config = {
        extra = {
            xmult0 = 1.1,
            chips0 = 50
        }
    },
    loc_txt = {
        ['name'] = 'Noelle',
        ['text'] = {
            [1] = '{X:red,C:white}x1.1{} Mult {C:blue}+50{} Chips'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 3,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["galaxysf_galaxysf_jokers"] = true, ["galaxysf_galaxysf_darkener"] = true },
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                Xmult = 1.1,
                extra = {
                    chips = 50,
                    colour = G.C.CHIPS
                }
            }
        end
    end
}