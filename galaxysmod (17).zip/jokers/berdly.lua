
SMODS.Joker{ --Berdly
    key = "berdly",
    config = {
        extra = {
            xmult0 = 0.75,
            chips0 = -100,
            odds = 4
        }
    },
    loc_txt = {
        ['name'] = 'Berdly',
        ['text'] = {
            [1] = '{X:red,C:white}X0.75{} Mult {C:red}-100{} Chips {C:green}#1# in 4{} chance to be destroyed'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 4,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 1,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["galaxysf_galaxysf_jokers"] = true, ["galaxysf_galaxysf_darkener"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_galaxysf_berdly') 
        return {vars = {new_numerator, new_denominator}}
    end,
    
    set_ability = function(self, card, initial)
        card:set_eternal(true)
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if true then
                return {
                    Xmult = 0.75,
                    extra = {
                        chips = -100,
                        colour = G.C.CHIPS
                    }
                    ,
                    func = function()
                        if SMODS.pseudorandom_probability(card, 'group_0_f0b6cd87', 1, card.ability.extra.odds, 'j_galaxysf_berdly', false) then
                            local target_joker = card
                            
                            if target_joker then
                                target_joker.getting_sliced = true
                                G.E_MANAGER:add_event(Event({
                                    func = function()
                                        target_joker:start_dissolve({G.C.RED}, nil, 1.6)
                                        return true
                                    end
                                }))
                                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Destroyed!", colour = G.C.RED})
                            end
                            
                        end
                        return true
                    end
                }
            end
        end
    end
}