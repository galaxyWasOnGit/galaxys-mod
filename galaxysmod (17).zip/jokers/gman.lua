
SMODS.Joker{ --Gman
    key = "gman",
    config = {
        extra = {
            emult0 = 75,
            dollars0 = 999
        }
    },
    loc_txt = {
        ['name'] = 'Gman',
        ['text'] = {
            [1] = 'THE GOD OF ALL GALAXY\'S MOD',
            [2] = '',
            [3] = '({X:tarot,C:white}1^75{} Mult, {C:money}$999{} Per Card Scored, {C:green}100% {}Chance to summon a random negative joker'
            },
            ['unlock'] = {
                [1] = 'Unlocked by default.'
            }
        },
        pos = {
            x = 8,
            y = 8
        },
        display_size = {
            w = 71 * 1, 
            h = 95 * 1
        },
        cost = 500,
        rarity = "galaxysf_godly",
        blueprint_compat = true,
        eternal_compat = true,
        perishable_compat = true,
        unlocked = true,
        discovered = true,
        atlas = 'CustomJokers',
        pools = { ["galaxysf_galaxysf_godlys"] = true },
        
        calculate = function(self, card, context)
            if context.individual and context.cardarea == G.play  then
                local created_joker = false
                if #G.jokers.cards + G.GAME.joker_buffer < G.jokers.config.card_limit then
                    created_joker = true
                    G.GAME.joker_buffer = G.GAME.joker_buffer + 1
                    G.E_MANAGER:add_event(Event({
                        func = function()
                            local joker_card = SMODS.add_card({ set = 'Joker' })
                            if joker_card then
                                joker_card:set_edition("e_negative", true)
                                
                            end
                            G.GAME.joker_buffer = 0
                            return true
                        end
                    }))
                end
                return {
                    e_mult = 75,
                    extra = {
                        
                        func = function()
                            
                            local current_dollars = G.GAME.dollars
                            local target_dollars = G.GAME.dollars + 999
                            local dollar_value = target_dollars - current_dollars
                            ease_dollars(dollar_value)
                            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(999), colour = G.C.MONEY})
                            return true
                        end,
                        colour = G.C.MONEY,
                        extra = {
                            message = created_joker and localize('k_plus_joker') or nil,
                            colour = G.C.BLUE
                        }
                    }
                }
            end
            if context.first_hand_drawn  then
                G.E_MANAGER:add_event(Event({
                    func = function()
                        play_sound("galaxysf_Gman")
                        
                        return true
                    end,
                }))
            end
        end
    }