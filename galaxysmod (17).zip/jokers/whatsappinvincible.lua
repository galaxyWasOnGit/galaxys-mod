
SMODS.Joker{ --Whatsapp Invincible
    key = "whatsappinvincible",
    config = {
        extra = {
            xchips0 = 150,
            xmult0 = 75,
            odds = 3,
            dollars0 = 50
        }
    },
    loc_txt = {
        ['name'] = 'Whatsapp Invincible',
        ['text'] = {
            [1] = '{X:red,C:white}X75 {} Mult For Scored Cards And {X:blue,C:white}X150{} Chips For Scored Cards',
            [2] = '',
            [3] = '{C:green}#1# in 3 {}Chance To earn {C:gold}$50{} Per Round'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 7,
        y = 8
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 500,
    rarity = "galaxysf_godly",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["galaxysf_galaxysf_godlys"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_galaxysf_whatsappinvincible') 
        return {vars = {new_numerator, new_denominator}}
    end,
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            return {
                x_chips = 150,
                extra = {
                    Xmult = 75
                }
            }
        end
        if context.end_of_round and context.game_over == false and context.main_eval  then
            if true then
                if SMODS.pseudorandom_probability(card, 'group_0_612d184b', 1, card.ability.extra.odds, 'j_galaxysf_whatsappinvincible', false) then
                    SMODS.calculate_effect({
                        func = function()
                            
                            local current_dollars = G.GAME.dollars
                            local target_dollars = G.GAME.dollars + 50
                            local dollar_value = target_dollars - current_dollars
                            ease_dollars(dollar_value)
                            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(50), colour = G.C.MONEY})
                            return true
                        end}, card)
                    end
                end
            end
        end
    }