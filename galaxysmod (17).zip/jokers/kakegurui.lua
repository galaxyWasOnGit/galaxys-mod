
SMODS.Joker{ -- Kakegurui
    key = "kakegurui",
    config = {
        extra = {
            xchips0 = 2.25
        }
    },
    loc_txt = {
        ['name'] = ' Kakegurui',
        ['text'] = {
            [1] = '{X:blue,C:white}X2.25{} Chips On {C:hearts}Hearts{} Played'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 6,
        y = 10
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["galaxysf_galaxysf_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if context.other_card:is_suit("Hearts") then
                return {
                    x_chips = 2.25
                }
            end
        end
    end
}