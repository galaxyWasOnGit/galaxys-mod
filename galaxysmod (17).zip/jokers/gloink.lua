
SMODS.Joker{ --Gloink
    key = "gloink",
    config = {
        extra = {
            mult0 = 4
        }
    },
    loc_txt = {
        ['name'] = 'Gloink',
        ['text'] = {
            [1] = 'Does Nothing?',
            [2] = '',
            [3] = 'Maybe select a certain tadc character to activate its true power',
            [4] = '',
            [5] = '{C:red}+4{} Mult? bruh'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 8,
        y = 13
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["galaxysf_galaxysf_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if #G.jokers.highlighted > 0 and G.jokers.highlighted[1].config.center.key == "j_galaxysf_zooble" then
                return {
                    mult = 4
                }
            end
        end
    end
}