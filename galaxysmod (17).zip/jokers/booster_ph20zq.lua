
SMODS.Joker{ --$&!&#$*)%*!&#
key = "booster_ph20zq",
config = {
    extra = {
    }
},
loc_txt = {
['name'] = '$&!&#$*)%*!&#',
['text'] = {
    [1] = 'Gives every card played a random {C:hearts}Seal{} {C:planet} Enchancement{} and {C:dark_edition}Edition{}',
    [2] = '',
    [3] = '(doesnt ignore cards already randomized]'
    },
    ['unlock'] = {
        [1] = 'Unlocked by default.'
    }
},
pos = {
    x = 3,
    y = 15
},
display_size = {
    w = 71 * 1, 
    h = 95 * 1
},
cost = 4,
rarity = 1,
blueprint_compat = true,
eternal_compat = true,
perishable_compat = true,
unlocked = true,
discovered = true,
atlas = 'CustomJokers',
pools = { ["galaxysf_galaxysf_jokers"] = true },

calculate = function(self, card, context)
    if context.individual and context.cardarea == G.play  then
        local scored_card = context.other_card
        G.E_MANAGER:add_event(Event({
            func = function()
                
                local enhancement_pool = {}
                for _, enhancement in pairs(G.P_CENTER_POOLS.Enhanced) do
                    if enhancement.key ~= 'm_stone' then
                        enhancement_pool[#enhancement_pool + 1] = enhancement
                    end
                end
                local random_enhancement = pseudorandom_element(enhancement_pool, 'edit_card_enhancement')
                scored_card:set_ability(random_enhancement)
                local random_seal = SMODS.poll_seal({mod = 10, guaranteed = true})
                if random_seal then
                    scored_card:set_seal(random_seal, true)
                end
                local edition = pseudorandom_element({'e_foil','e_holo','e_polychrome','e_negative','e_galaxysf_burnt','e_galaxysf_gay','e_galaxysf_gilded','e_galaxysf_laminated'}, 'random edition')
                if random_edition then
                    scored_card:set_edition(random_edition, true)
                end
                card_eval_status_text(scored_card, 'extra', nil, nil, nil, {message = "Card Modified!", colour = G.C.ORANGE})
                return true
            end
        }))
    end
end
}