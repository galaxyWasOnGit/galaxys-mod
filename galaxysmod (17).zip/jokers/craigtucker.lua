
SMODS.Joker{ --Craig Tucker
    key = "craigtucker",
    config = {
        extra = {
            xchips0 = 8
        }
    },
    loc_txt = {
        ['name'] = 'Craig Tucker',
        ['text'] = {
            [1] = 'If Tweak Is Selected {X:blue,C:white}X8{} Chips'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 8
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["galaxysf_galaxysf_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if #G.jokers.highlighted > 0 and G.jokers.highlighted[1].config.center.key == "j_galaxysf_tweektweak" then
                return {
                    x_chips = 8
                }
            end
        end
    end
}