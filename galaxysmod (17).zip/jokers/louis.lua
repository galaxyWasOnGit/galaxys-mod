
SMODS.Joker{ --Louis
    key = "louis",
    config = {
        extra = {
            xmult0 = 5
        }
    },
    loc_txt = {
        ['name'] = 'Louis',
        ['text'] = {
            [1] = 'Gives {X:red,C:white}X5{} Mult when you have more than 3 jokers',
            [2] = '',
            [3] = '(Why the long snout?)',
            [4] = '',
            [5] = '(Cybron\'s Dog)'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 2,
        y = 8
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = "galaxysf_pet",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["galaxysf_galaxysf_jokers"] = true, ["galaxysf_galaxysf_pets"] = true },
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if to_big(#G.jokers.cards) > to_big(2) then
                return {
                    Xmult = 5
                }
            end
        end
    end
}