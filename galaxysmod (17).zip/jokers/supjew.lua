
SMODS.Joker{ --Sup Jew?
    key = "supjew",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'Sup Jew?',
        ['text'] = {
            [1] = 'no.... just no.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 9,
        y = 8
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = "galaxysf_godly",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["galaxysf_galaxysf_godlys"] = true },
    
    set_ability = function(self, card, initial)
        card:set_eternal(true)
        card:add_sticker('perishable', true)
    end
}