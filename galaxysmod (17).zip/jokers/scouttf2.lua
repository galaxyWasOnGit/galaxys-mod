
SMODS.Joker{ --Scout Tf2
    key = "scouttf2",
    config = {
        extra = {
            xchips0 = 1.01
        }
    },
    loc_txt = {
        ['name'] = 'Scout Tf2',
        ['text'] = {
            [1] = '{X:blue,C:white}X1.01{} Chips, Sets Game Speed to X4'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 1,
        y = 7
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["galaxysf_galaxysf_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                x_chips = 1.01
            }
        end
        if context.first_hand_drawn  then
            G.SETTINGS.GAMESPEED = 4
        end
    end
}