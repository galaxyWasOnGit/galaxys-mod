
SMODS.Joker{ --Dick Hoppin
    key = "dickhoppin",
    config = {
        extra = {
            dickhoppin = 1
        }
    },
    loc_txt = {
        ['name'] = 'Dick Hoppin',
        ['text'] = {
            [1] = '{X:red,C:white}X1.015{} Mult For Every Card You\'ve Played',
            [2] = '(Currently: {X:red,C:white}X#1# {} Mult'
            },
            ['unlock'] = {
                [1] = 'Unlocked by default.'
            }
        },
        pos = {
            x = 3,
            y = 12
        },
        display_size = {
            w = 71 * 1, 
            h = 95 * 1
        },
        cost = 4,
        rarity = 3,
        blueprint_compat = true,
        eternal_compat = true,
        perishable_compat = true,
        unlocked = true,
        discovered = true,
        atlas = 'CustomJokers',
        pools = { ["galaxysf_galaxysf_jokers"] = true },
        
        loc_vars = function(self, info_queue, card)
            
            return {vars = {card.ability.extra.dickhoppin}}
        end,
        
        calculate = function(self, card, context)
            if context.individual and context.cardarea == G.play  then
                card.ability.extra.dickhoppin = (card.ability.extra.dickhoppin) + 0.015
            end
            if context.cardarea == G.jokers and context.joker_main  then
                return {
                    Xmult = card.ability.extra.dickhoppin
                }
            end
        end
    }