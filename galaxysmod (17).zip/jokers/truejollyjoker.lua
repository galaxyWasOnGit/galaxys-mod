
SMODS.Joker{ --True Jolly Joker
    key = "truejollyjoker",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'True Jolly Joker',
        ['text'] = {
            [1] = '{X:tarot,C:white}^100{} Mult If The Hand Is a {C:attention}Pair{}',
            [2] = '',
            [3] = '{E:1}THE TRUE GOD OF ALL BALATRO{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 9,
        y = 12
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = "galaxysf_godly",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["galaxysf_galaxysf_godlys"] = true },
    soul_pos = {
        x = 0,
        y = 13
    },
    in_pool = function(self, args)
        return (
            not args 
            or args.source ~= 'sho' 
            or args.source == 'buf' or args.source == 'jud' or args.source == 'rif' or args.source == 'rta' or args.source == 'sou' or args.source == 'uta' or args.source == 'wra'
        )
        and true
    end
}