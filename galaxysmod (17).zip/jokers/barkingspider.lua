
SMODS.Joker{ --Barking Spider
    key = "barkingspider",
    config = {
        extra = {
            xchips0 = 1.11
        }
    },
    loc_txt = {
        ['name'] = 'Barking Spider',
        ['text'] = {
            [1] = 'Gives {X:blue,C:white}X1.11 {} Chips on each card'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 7,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["galaxysf_galaxysf_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            G.E_MANAGER:add_event(Event({
                func = function()
                    play_sound("galaxysf_Barkingspider")
                    SMODS.calculate_effect({message = "*fart*"}, card)
                    return true
                end,
            }))
            return {
                x_chips = 1.11
            }
        end
    end
}