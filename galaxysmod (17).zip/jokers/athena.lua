
SMODS.Joker{ --Athena
    key = "athena",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'Athena',
        ['text'] = {
            [1] = 'Rounds Your Chips And Mult',
            [2] = '',
            [3] = '(Bubbles\'s Cat)'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 5,
        y = 9
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 20,
    rarity = "galaxysf_pet",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["galaxysf_galaxysf_jokers"] = true, ["galaxysf_galaxysf_pets"] = true },
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                balance = true
            }
        end
    end
}